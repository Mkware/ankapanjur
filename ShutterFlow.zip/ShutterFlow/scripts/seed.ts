import { Pool } from '@neondatabase/serverless';
import bcrypt from 'bcryptjs';
import 'dotenv/config';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function seed() {
  console.log('🌱 Veritabanı başlangıç verilerini yükleniyor...');

  try {
    // Admin kullanıcısı oluştur
    const hashedPassword = await bcrypt.hash('admin123', 10);
    
    await pool.query(`
      INSERT INTO users (id, username, password) 
      VALUES ($1, $2, $3)
      ON CONFLICT (username) DO NOTHING
    `, ['admin-user-id', 'admin', hashedPassword]);

    // Site ayarları
    await pool.query(`
      INSERT INTO site_settings (
        id, site_name, site_description, hero_title, hero_subtitle, 
        hero_button_text, about_title, about_description, services_title, 
        services_description, contact_title, contact_description, meta_keywords
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13
      ) ON CONFLICT (id) DO UPDATE SET
        site_name = EXCLUDED.site_name,
        site_description = EXCLUDED.site_description,
        hero_title = EXCLUDED.hero_title,
        hero_subtitle = EXCLUDED.hero_subtitle
    `, [
      'site-settings-id',
      'AnkaPanjur - Ankara Panjur Kepenk Sistemleri',
      'Profesyonel otomasyon kepenk, kapı ve güvenlik sistemleri. 10 yıllık deneyim, kaliteli hizmet.',
      'Otomasyon Kepenk ve Kapı Sistemleri',
      'Güvenilir kepenk, kapı ve otomasyon çözümleri ile yaşam alanlarınızı koruyoruz',
      'Hizmetlerimizi Keşfedin',
      'Hakkımızda',
      'AnkaPanjur olarak 10 yıldır otomasyon sektöründe faaliyet gösteriyoruz',
      'Hizmetlerimiz',
      'Kaliteli malzeme ve profesyonel montaj ile sizlere hizmet veriyoruz',
      'İletişim',
      'Profesyonel danışmanlık ve hızlı çözümler için bizimle iletişime geçin',
      'otomasyon, kepenk, kapı, güvenlik, ankara, panjur, otomatik kepenk'
    ]);

    // Şirket bilgileri
    await pool.query(`
      INSERT INTO company_info (
        id, name, subtitle, email, phone, address, city, 
        about_text, mission_text, vision_text, working_hours
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11
      ) ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        subtitle = EXCLUDED.subtitle,
        email = EXCLUDED.email,
        phone = EXCLUDED.phone
    `, [
      'company-info-id',
      'ANKAPANJUR',
      'Kepenk & Kapı Sistemleri',
      'info@ankapanjur.com',
      '+90 312 XXX XX XX',
      'Örnek Mahalle, Örnek Sokak No:1',
      'Ankara, Türkiye',
      '1998 yılından bu yana otomasyon kepenk ve kapı sistemleri sektöründe hizmet vermekteyiz.',
      'En kaliteli otomasyon sistemleri ile müşterilerimizin güvenlik ve konfor ihtiyaçlarını karşılamak',
      'Sektörde teknoloji ve yeniliğin öncüsü olarak Türkiye\'nin en güvenilir markası olmak',
      JSON.stringify({
        weekdays: 'Pazartesi - Cumartesi: 08:00 - 18:00',
        weekend: 'Pazar: Kapalı'
      })
    ]);

    // Ana sayfa özellikleri
    const features = [
      { title: '25 Yıl Deneyim', description: 'Sektörde uzun yıllara dayanan deneyimimiz', icon: 'Calendar' },
      { title: 'Profesyonel Ekip', description: 'Alanında uzman teknik personel kadromuz', icon: 'Users' },
      { title: 'Kaliteli Malzeme', description: 'Avrupa standartlarında kaliteli malzemeler', icon: 'Tag' },
      { title: '7/24 Destek', description: 'Kesintisiz müşteri destek hizmetimiz', icon: 'Headphones' },
      { title: 'Uygun Fiyat', description: 'Rekabetçi ve şeffaf fiyat politikamız', icon: 'DollarSign' },
      { title: 'Garanti', description: 'Tüm ürünlerimizde kapsamlı garanti', icon: 'Wrench' }
    ];

    for (const feature of features) {
      await pool.query(`
        INSERT INTO homepage_features (title, description, icon) 
        VALUES ($1, $2, $3)
        ON CONFLICT (title) DO NOTHING
      `, [feature.title, feature.description, feature.icon]);
    }

    // Başarılar
    const achievements = [
      { title: 'Tamamlanan Proje', number: '10K+', description: 'Başarıyla tamamladığımız proje sayısı' },
      { title: 'Yıl Deneyim', number: '25', description: 'Sektördeki deneyim yılımız' },
      { title: 'İl Genelinde', number: '81', description: 'Hizmet verdiğimiz il sayısı' }
    ];

    for (const achievement of achievements) {
      await pool.query(`
        INSERT INTO about_achievements (title, number, description) 
        VALUES ($1, $2, $3)
        ON CONFLICT (title) DO NOTHING
      `, [achievement.title, achievement.number, achievement.description]);
    }

    console.log('✅ Başlangıç verileri başarıyla yüklendi!');
    console.log('');
    console.log('Admin Giriş Bilgileri:');
    console.log('Kullanıcı adı: admin');
    console.log('Şifre: admin123');

  } catch (error) {
    console.error('❌ Seed işlemi sırasında hata:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

seed();