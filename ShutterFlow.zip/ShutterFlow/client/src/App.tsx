import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import About from "@/pages/About";
import Products from "@/pages/Products";
// Projects page removed
import Contact from "@/pages/Contact";
import ServiceDetail from "@/pages/ServiceDetail";
import Admin from "@/pages/Admin";
import AdminLogin from "@/pages/AdminLogin";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import LoadingScreen from "@/components/LoadingScreen";
import { useState, useEffect } from "react";

function Router() {
  return (
    <Switch>
      {/* Admin routes without header/footer */}
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin" component={Admin} />
      
      {/* Regular routes with header/footer */}
      <Route path="/" component={Home} />
      <Route path="/hakkimizda" component={About} />
      <Route path="/urunler" component={Products} />
      {/* Projects route removed */}
      <Route path="/iletisim" component={Contact} />
      <Route path="/hizmet-detay" component={ServiceDetail} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        {isLoading && <LoadingScreen />}
        <div className="min-h-screen flex flex-col">
          <Switch>
            {/* Admin routes without header/footer */}
            <Route path="/admin/login" component={AdminLogin} />
            <Route path="/admin" component={Admin} />
            
            {/* Regular routes with header/footer */}
            <Route>
              {() => (
                <>
                  <Header />
                  <main className="flex-1">
                    <Switch>
                      <Route path="/" component={Home} />
                      <Route path="/hakkimizda" component={About} />
                      <Route path="/urunler" component={Products} />
                      {/* Projects route removed */}
                      <Route path="/iletisim" component={Contact} />
                      <Route path="/hizmet-detay" component={ServiceDetail} />
                      <Route component={NotFound} />
                    </Switch>
                  </main>
                  <Footer />
                  <WhatsAppButton />
                </>
              )}
            </Route>
          </Switch>
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
