import { useEffect, useState } from "react";
import ServiceCard from "@/components/ServiceCard";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { SERVICES } from "@/lib/constants";
import { useSEO } from "@/hooks/useSEO";

export default function Products() {
  const [categoryFilter, setCategoryFilter] = useState("all");

  // Fetch services from database
  const { data: services = [] } = useQuery({
    queryKey: ['/api/public/services'],
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['/api/public/site-settings'],
  });

  // SEO setup
  useSEO({
    title: `Ürünler ve Hizmetler | ${siteSettings?.siteName || "AnkaPanjur"}`,
    description: siteSettings?.servicesDescription || "Kaliteli malzeme ve profesyonel montaj ile otomasyon kepenk, kapı ve güvenlik sistemleri hizmetleri.",
    keywords: siteSettings?.metaKeywords || "ürünler, hizmetler, otomasyon kepenk, kapı sistemleri, panjur, seksiyonel kapı"
  });

  const filteredServices = categoryFilter === "all" 
    ? services 
    : services.filter((service: any) => service.category === categoryFilter);

  const filterButtons = [
    { key: "all", label: "Tüm Ürünler" },
    { key: "industrial", label: "Endüstriyel" },
    { key: "commercial", label: "Ticari" },
    { key: "residential", label: "Konut" }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-display font-bold mb-6">
              {siteSettings?.servicesTitle || "Ürünlerimiz"}
            </h1>
            <p className="text-xl max-w-3xl mx-auto text-blue-50 font-medium">
              {siteSettings?.servicesDescription || "Endüstriyel kalitede otomasyon sistemleri ile güvenlik ve konforunuzu en üst seviyeye çıkarıyoruz"}
            </p>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          {/* Filter Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {filterButtons.map((button) => (
              <Button
                key={button.key}
                variant={categoryFilter === button.key ? "default" : "outline"}
                onClick={() => setCategoryFilter(button.key)}
                className={categoryFilter === button.key ? "bg-primary text-white" : ""}
              >
                {button.label}
              </Button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredServices.map((service: any) => (
              <ServiceCard
                key={service.id}
                title={service.title}
                description={service.description}
                image={service.images?.[0] || "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=600&fit=crop"}
                icon={service.icon}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Product Details Sections */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Ürün Kategorileri</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Her sektöre özel tasarlanmış profesyonel otomasyon çözümleri
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Industrial Category */}
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4 text-center">Endüstriyel Sistemler</h3>
              <ul className="text-gray-600 space-y-2">
                <li>• Seksiyonel Kapı Sistemleri</li>
                <li>• Endüstriyel Kapı Sistemleri</li>
                <li>• Giyotin Sistemleri</li>
                <li>• Ağır hizmet tipi çözümler</li>
                <li>• Yüksek güvenlik standartları</li>
              </ul>
            </div>

            {/* Commercial Category */}
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4 text-center">Ticari Sistemler</h3>
              <ul className="text-gray-600 space-y-2">
                <li>• Kepenk Sistemleri</li>
                <li>• Fotoselli Kapı Sistemleri</li>
                <li>• Yangın Kapıları</li>
                <li>• Kollu Bariyer Sistemleri</li>
                <li>• Akıllı kontrol sistemleri</li>
              </ul>
            </div>

            {/* Residential Category */}
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="bg-purple-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4 text-center">Konut Sistemleri</h3>
              <ul className="text-gray-600 space-y-2">
                <li>• Panjur Sistemleri</li>
                <li>• Otomatik Kayar Bahçe Kapısı</li>
                <li>• Pergole Sistemleri</li>
                <li>• Ev güvenlik çözümleri</li>
                <li>• Estetik ve fonksiyonel tasarım</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Ürün Özelliklerimiz</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Tüm ürünlerimizde standart olan kalite özellikleri
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Güvenlik</h3>
              <p className="text-gray-600 text-sm">Yüksek güvenlik standartları ve sağlam yapı</p>
            </div>

            <div className="text-center p-6">
              <div className="bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                </svg>
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Otomasyon</h3>
              <p className="text-gray-600 text-sm">Akıllı kontrol ve kumanda sistemleri</p>
            </div>

            <div className="text-center p-6">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M3 6a3 3 0 013-3h10a1 1 0 01.8 1.6L14.25 8l2.55 3.4A1 1 0 0116 13H6a1 1 0 00-1 1v3a1 1 0 11-2 0V6z" clipRule="evenodd" />
                </svg>
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Dayanıklılık</h3>
              <p className="text-gray-600 text-sm">Uzun ömürlü ve dayanıklı malzemeler</p>
            </div>

            <div className="text-center p-6">
              <div className="bg-purple-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z" clipRule="evenodd" />
                </svg>
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Kalite</h3>
              <p className="text-gray-600 text-sm">Uluslararası kalite standartlarında üretim</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
