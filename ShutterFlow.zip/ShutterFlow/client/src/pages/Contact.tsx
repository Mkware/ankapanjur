import { useEffect } from "react";
import ContactForm from "@/components/ContactForm";
import { MapPin, Phone, Mail, Clock, MessageCircle, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { COMPANY_INFO } from "@/lib/constants";
import { useSEO } from "@/hooks/useSEO";

export default function Contact() {
  // Fetch company info from database
  const { data: companyInfo } = useQuery({
    queryKey: ['/api/public/company-info'],
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['/api/public/site-settings'],
  });

  // SEO setup
  useSEO({
    title: `İletişim | ${siteSettings?.siteName || "AnkaPanjur"}`,
    description: siteSettings?.contactDescription || "Profesyonel danışmanlık ve hızlı çözümler için bizimle iletişime geçin. Ücretsiz keşif ve teklif.",
    keywords: siteSettings?.metaKeywords || "iletişim, teklif, keşif, otomasyon, kepenk, ankara"
  });

  const handleWhatsAppClick = () => {
    const message = "Merhaba, otomasyon sistemleri hakkında bilgi almak istiyorum.";
    const phoneNumber = (companyInfo?.phone || COMPANY_INFO.phone).replace(/\s/g, "");
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-display font-bold mb-6">
              {siteSettings?.contactTitle || "İletişim"}
            </h1>
            <p className="text-xl max-w-3xl mx-auto text-blue-50 font-medium">
              {siteSettings?.contactDescription || "Projeleriniz için ücretsiz keşif ve fiyat teklifi almak için bize ulaşın"}
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <ContactForm />

            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-6">İletişim Bilgileri</h3>

                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="bg-primary text-white w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800">Adres</h4>
                      <p className="text-gray-600">
                        {companyInfo?.address || COMPANY_INFO.address}<br />
                        {companyInfo?.city || COMPANY_INFO.city}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-accent text-white w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800">Telefon</h4>
                      <a href={`tel:${companyInfo?.phone || COMPANY_INFO.phone}`} className="text-primary hover:text-primary/80 transition-colors">
                        {companyInfo?.phone || COMPANY_INFO.phone}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-green-600 text-white w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MessageCircle size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800">WhatsApp</h4>
                      <button 
                        onClick={handleWhatsAppClick}
                        className="text-green-600 hover:text-green-700 transition-colors"
                      >
                        {companyInfo?.phone || COMPANY_INFO.phone}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-blue-600 text-white w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800">E-posta</h4>
                      <a href={`mailto:${companyInfo?.email || COMPANY_INFO.email}`} className="text-blue-600 hover:text-blue-700 transition-colors">
                        {companyInfo?.email || COMPANY_INFO.email}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="bg-purple-600 text-white w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Clock size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800">Çalışma Saatleri</h4>
                      <p className="text-gray-600">{COMPANY_INFO.workingHours.weekdays}<br />{COMPANY_INFO.workingHours.weekend}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Action Buttons */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-gray-800">Hızlı İletişim</h4>
                
                <Button 
                  onClick={handleWhatsAppClick}
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                >
                  <MessageCircle className="mr-2" size={16} />
                  WhatsApp ile Mesaj Gönder
                </Button>
                
                <Button 
                  asChild
                  className="w-full bg-accent hover:bg-accent/90 text-white"
                >
                  <a href={`tel:${COMPANY_INFO.phone}`}>
                    <Phone className="mr-2" size={16} />
                    Hemen Ara
                  </a>
                </Button>
              </div>

              {/* Google Maps Placeholder */}
              <div className="bg-gray-200 rounded-xl h-64 flex items-center justify-center">
                <div className="text-center text-gray-600">
                  <MapPin size={48} className="mx-auto mb-4" />
                  <p className="font-medium">Google Maps Haritası</p>
                  <p className="text-sm">Konum: {COMPANY_INFO.city}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Info Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <div className="bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Calendar size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Ücretsiz Keşif</h3>
              <p className="text-gray-600">
                Projeleriniz için ücretsiz keşif hizmeti sunuyoruz. Uzman ekibimiz size en uygun çözümü sunar.
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <div className="bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <MessageCircle size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">7/24 Destek</h3>
              <p className="text-gray-600">
                Müşterilerimize 7 gün 24 saat destek hizmeti sunuyoruz. Acil durumlar için hemen ulaşın.
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Phone size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Hızlı Yanıt</h3>
              <p className="text-gray-600">
                Tüm sorularınızı en geç 2 saat içinde yanıtlıyoruz. Hızlı ve etkili iletişim için buradayız.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
