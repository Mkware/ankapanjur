import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import ServiceCard from "@/components/ServiceCard";
// ProjectCard removed
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Calendar, MessageCircle, Award, Users, Tag, Headphones, DollarSign, Wrench, CheckCircle, Eye, Star, MapPin, Phone, Mail, Clock, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { SERVICES, COMPANY_INFO } from "@/lib/constants";
import { useSEO } from "@/hooks/useSEO";

export default function Home() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  // Project filter removed

  // Fetch data from database
  const { data: services = [] } = useQuery({
    queryKey: ['/api/public/services'],
  });

  // Projects removed

  const { data: companyInfo } = useQuery({
    queryKey: ['/api/public/company-info'],
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['/api/public/site-settings'],
  });

  const { data: featuresFromDB = [] } = useQuery({
    queryKey: ['/api/public/homepage-features'],
  });

  const { data: aboutAchievements = [] } = useQuery({
    queryKey: ['/api/public/about-achievements'],
  });

  // SEO setup
  useSEO({
    title: siteSettings?.siteName ? `${siteSettings.siteName} | Ana Sayfa` : "AnkaPanjur - Otomasyon Kepenk ve Kapı Sistemleri | Ana Sayfa",
    description: siteSettings?.siteDescription || "Profesyonel otomasyon kepenk, kapı ve güvenlik sistemleri. 10 yıllık deneyim, kaliteli hizmet.",
    keywords: siteSettings?.metaKeywords || "otomasyon, kepenk, kapı, güvenlik, ankara, panjur, otomatik kepenk",
    ogImage: (siteSettings as any)?.heroImage
  });

  // Project filtering removed

  // Get icon component from name
  const getIconComponent = (iconName: string) => {
    const icons: Record<string, any> = {
      Calendar, Users, Tag, Headphones, DollarSign, Wrench, Award, CheckCircle, Eye, Star
    };
    return icons[iconName] || CheckCircle;
  };

  const features = (featuresFromDB as any[]).map((feature: any) => ({
    icon: getIconComponent(feature.icon),
    title: feature.title,
    description: feature.description
  }));

  // Filter buttons removed

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="hero-gradient min-h-screen flex items-center">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h1 className="text-4xl lg:text-5xl font-display font-bold mb-6 leading-tight">
                {(siteSettings as any)?.heroTitle || "Profesyonel Otomasyon Kepenk ve Kapı Sistemleri"}
              </h1>
              <p className="text-xl mb-8 text-blue-50 leading-relaxed font-medium">
                {(siteSettings as any)?.heroSubtitle || "AnkaPanjur olarak önceliğimiz yüksek kaliteli ve uzun ömürlü sistemler üretmek ve uygulamaktır."}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button 
                  className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg"
                  onClick={() => {
                    const message = "Merhaba, otomasyon sistemleri hakkında bilgi almak istiyorum.";
                    const phoneNumber = (companyInfo?.phone || COMPANY_INFO.phone).replace(/\s/g, "");
                    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
                    window.open(whatsappUrl, "_blank");
                  }}
                >
                  <svg className="mr-2" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.488"/>
                  </svg>
                  WhatsApp İletişim
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="flex flex-wrap items-center gap-6 text-blue-100 font-medium">
                <div className="flex items-center space-x-2">
                  <Tag className="text-yellow-400" size={20} />
                  <span>ISO Kalitesi</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Award className="text-yellow-400" size={20} />
                  <span>10 Yıllık Deneyim</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <img 
                src={(siteSettings as any)?.heroImage || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=800"} 
                alt="Modern automated industrial building" 
                className="rounded-2xl shadow-2xl w-full h-auto" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-display font-bold text-foreground mb-6">
              {(siteSettings as any)?.servicesTitle || "Ürün ve Hizmetlerimiz"}
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-medium">
              {(siteSettings as any)?.servicesDescription || "Endüstriyel kalitede otomasyon sistemleri ile güvenlik ve konforunuzu en üst seviyeye çıkarıyoruz"}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {(services as any[]).map((service: any) => (
              <ServiceCard
                key={service.id}
                title={service.title}
                description={service.description}
                image={service.images?.[0] || "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=600&fit=crop"}
                icon={service.icon}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Projects section removed */}

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-display font-bold text-foreground mb-6">Neden Bizi Seçmelisiniz?</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-medium">
              {companyInfo?.aboutText || "25 yıllık deneyimimiz ve müşteri odaklı yaklaşımımızla sektörde öncü konumdayız"}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-8 bg-gray-50 rounded-xl">
                <div className="bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <feature.icon size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl lg:text-5xl font-display font-bold text-foreground mb-6">Hakkımızda</h2>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed font-medium">
                {companyInfo?.aboutText || "1998 yılından bu yana otomasyon kepenk ve kapı sistemleri sektöründe hizmet vermekteyiz. Kalite, güvenilirlik ve müşteri memnuniyeti odaklı yaklaşımımızla Türkiye'nin önde gelen firmalarından biri haline geldik."}
              </p>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-gray-800">Misyonumuz</h4>
                    <p className="text-gray-600">{companyInfo?.missionText || "En kaliteli otomasyon sistemleri ile müşterilerimizin güvenlik ve konfor ihtiyaçlarını karşılamak"}</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-primary text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Eye size={16} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-gray-800">Vizyonumuz</h4>
                    <p className="text-gray-600">{companyInfo?.visionText || "Sektörde teknoloji ve yeniliğin öncüsü olarak Türkiye'nin en güvenilir markası olmak"}</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-primary text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <Star size={16} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-gray-800">Değerlerimiz</h4>
                    <p className="text-gray-600">{companyInfo?.aboutText ? "Dürüstlük, kalite, güvenilirlik ve müşteri odaklılık temel değerlerimizdir" : "Dürüstlük, kalite, güvenilirlik ve müşteri odaklılık temel değerlerimizdir"}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Professional automation team at work" 
                className="rounded-2xl shadow-xl w-full h-auto" 
              />

              {/* Stats Overlay */}
              <div className="absolute bottom-8 left-8 right-8">
                <div className="bg-white/95 backdrop-blur-sm rounded-xl p-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    {(aboutAchievements as any[]).slice(0, 3).map((achievement: any, index: number) => (
                      <div key={index}>
                        <div className="text-2xl font-bold text-primary">{achievement.number}</div>
                        <div className="text-sm text-gray-600">{achievement.title}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-display font-bold text-foreground mb-6">{(siteSettings as any)?.contactTitle || "Hızlı İletişim"}</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-medium">
              {(siteSettings as any)?.contactDescription || "Projeleriniz için bilgi almak ve ücretsiz keşif talebinde bulunmak için bize ulaşın"}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-primary text-white w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <MapPin size={20} />
              </div>
              <h4 className="font-bold text-gray-800 mb-2">Adres</h4>
              <p className="text-gray-600 text-sm">{COMPANY_INFO.address}<br />{COMPANY_INFO.city}</p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-accent text-white w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Phone size={20} />
              </div>
              <h4 className="font-bold text-gray-800 mb-2">Telefon</h4>
              <a href={`tel:${COMPANY_INFO.phone}`} className="text-primary hover:text-primary/80 transition-colors">
                {COMPANY_INFO.phone}
              </a>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-blue-600 text-white w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Mail size={20} />
              </div>
              <h4 className="font-bold text-gray-800 mb-2">E-posta</h4>
              <a href={`mailto:${COMPANY_INFO.email}`} className="text-blue-600 hover:text-blue-700 transition-colors">
                {COMPANY_INFO.email}
              </a>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-purple-600 text-white w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Clock size={20} />
              </div>
              <h4 className="font-bold text-gray-800 mb-2">Çalışma Saatleri</h4>
              <p className="text-gray-600 text-sm">Pzt-Cmt: 08:00-18:00<br />Pazar: 10:00-16:00</p>
            </div>
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0">
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 z-10 text-white hover:text-gray-300"
              onClick={() => setSelectedImage(null)}
            >
              <X size={24} />
            </Button>
            {selectedImage && (
              <img
                src={selectedImage}
                alt="Project image"
                className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
