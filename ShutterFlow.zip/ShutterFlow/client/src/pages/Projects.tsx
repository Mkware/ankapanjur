import { useEffect, useState } from "react";
import ProjectCard from "@/components/ProjectCard";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { PROJECTS } from "@/lib/constants";

export default function Projects() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState("all");

  // Fetch projects from database
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/public/projects'],
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['/api/public/site-settings'],
  });

  useEffect(() => {
    document.title = "Projeler | ANKAPANJUR - Kepenk ve Kapı Sistemleri";
  }, []);

  const filteredProjects = categoryFilter === "all" 
    ? projects 
    : projects.filter((project: any) => project.category === categoryFilter);

  const filterButtons = [
    { key: "all", label: "Tüm Projeler" },
    { key: "industrial", label: "Endüstriyel" },
    { key: "commercial", label: "Ticari" },
    { key: "residential", label: "Konut" }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-display font-bold mb-6">
              {siteSettings?.projectsTitle || "Projelerimiz"}
            </h1>
            <p className="text-xl max-w-3xl mx-auto text-blue-50 font-medium">
              {siteSettings?.projectsDescription || "Türkiye'nin dört bir yanında gerçekleştirdiğimiz başarılı projelerimizi keşfedin"}
            </p>
          </div>
        </div>
      </section>

      {/* Projects Gallery */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          {/* Filter Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {filterButtons.map((button) => (
              <Button
                key={button.key}
                variant={categoryFilter === button.key ? "default" : "outline"}
                onClick={() => setCategoryFilter(button.key)}
                className={categoryFilter === button.key ? "bg-primary text-white" : ""}
              >
                {button.label}
              </Button>
            ))}
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project: any) => (
              <ProjectCard
                key={project.id}
                title={project.title}
                description={project.description}
                image={project.image}
                category={project.category}
                onImageClick={setSelectedImage}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Project Stats */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Proje İstatistikleri</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              25 yıllık deneyimimizin rakamlarla ifadesi
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <div className="text-4xl font-bold text-primary mb-2">10,000+</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Tamamlanan Proje</h3>
              <p className="text-gray-600">Başarıyla teslim edilmiş projeler</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <div className="text-4xl font-bold text-green-600 mb-2">81</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">İl Genelinde</h3>
              <p className="text-gray-600">Türkiye çapında hizmet ağı</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <div className="text-4xl font-bold text-blue-600 mb-2">%99</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Müşteri Memnuniyeti</h3>
              <p className="text-gray-600">Yüksek kalite ve hizmet standardı</p>
            </div>

            <div className="text-center p-8 bg-white rounded-xl shadow-lg">
              <div className="text-4xl font-bold text-purple-600 mb-2">10</div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">Yıl Deneyim</h3>
              <p className="text-gray-600">Sektördeki deneyimli geçmişimiz</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Öne Çıkan Projeler</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              En büyük ve en prestijli projelerimizden örnekler
            </p>
          </div>

          <div className="space-y-16">
            {/* Featured Project 1 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-3xl font-bold text-gray-800 mb-4">Büyük Endüstriyel Kompleks Projesi</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  İstanbul'da bulunan 50.000 m² alana sahip endüstriyel komplekste 50 adet seksiyonel kapı, 
                  20 adet endüstriyel kapı ve kapsamlı güvenlik sistemleri kurulumu gerçekleştirdik. 
                  Proje 3 ay sürede tamamlandı ve müşteri memnuniyeti %100 seviyesinde oldu.
                </p>
                <ul className="text-gray-600 space-y-2">
                  <li>• 50 adet seksiyonel kapı sistemi</li>
                  <li>• 20 adet endüstriyel kapı</li>
                  <li>• Entegre güvenlik sistemleri</li>
                  <li>• 7/24 teknik destek</li>
                </ul>
              </div>
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                  alt="Endüstriyel kompleks projesi"
                  className="rounded-xl shadow-lg w-full h-auto"
                />
              </div>
            </div>

            {/* Featured Project 2 */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="order-2 lg:order-1">
                <img 
                  src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                  alt="AVM projesi"
                  className="rounded-xl shadow-lg w-full h-auto"
                />
              </div>
              <div className="order-1 lg:order-2">
                <h3 className="text-3xl font-bold text-gray-800 mb-4">Prestijli AVM Projesi</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Ankara'nın en büyük alışveriş merkezlerinden birinde, 30 adet fotoselli kapı sistemi, 
                  yangın güvenlik kapıları ve acil çıkış sistemlerinin kurulumunu gerçekleştirdik. 
                  Proje modern tasarım ve yüksek güvenlik standartlarını bir araya getiriyor.
                </p>
                <ul className="text-gray-600 space-y-2">
                  <li>• 30 adet fotoselli kapı sistemi</li>
                  <li>• Yangın güvenlik kapıları</li>
                  <li>• Acil çıkış sistemleri</li>
                  <li>• Modern tasarım entegrasyonu</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] p-0">
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 z-10 text-white hover:text-gray-300"
              onClick={() => setSelectedImage(null)}
            >
              <X size={24} />
            </Button>
            {selectedImage && (
              <img
                src={selectedImage}
                alt="Project image"
                className="w-full h-auto max-h-[80vh] object-contain rounded-lg"
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
