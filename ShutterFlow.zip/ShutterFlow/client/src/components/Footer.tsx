import { Link } from "wouter";
import { DoorOpen, MapPin, Phone, Mail, Clock, Facebook, Instagram, Linkedin, Youtube } from "lucide-react";
import { COMPANY_INFO } from "@/lib/constants";
import { useQuery } from "@tanstack/react-query";

export default function Footer() {
  // Fetch company info from database
  const { data: companyInfo } = useQuery({
    queryKey: ['/api/public/company-info'],
  });

  // Use database data if available, fallback to constants
  const info = companyInfo || COMPANY_INFO;
  const quickLinks = [
    { href: "/", label: "Ana Sayfa" },
    { href: "/hakkimizda", label: "Hakkımızda" },
    { href: "/urunler", label: "Ürünler" },
    { href: "/projeler", label: "Projeler" },
    { href: "/iletisim", label: "İletişim" },
  ];

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-primary text-white p-3 rounded-lg">
                <DoorOpen size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-bold">{info.name}</h3>
                <p className="text-gray-400">{info.subtitle}</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              {info.aboutText || "25 yıllık deneyimimizle Türkiye'nin önde gelen otomasyon kepenk ve kapı sistemleri üreticisiyiz. Kalite, güvenilirlik ve müşteri memnuniyeti önceliğimizdir."}
            </p>
            <div className="flex space-x-4">
              <a href={(info.social?.instagram || COMPANY_INFO.social.instagram)} className="bg-pink-600 hover:bg-pink-700 w-10 h-10 rounded-lg flex items-center justify-center transition-colors">
                <Instagram size={16} />
              </a>
              <a href={(info.social?.linkedin || COMPANY_INFO.social.linkedin)} className="bg-blue-700 hover:bg-blue-800 w-10 h-10 rounded-lg flex items-center justify-center transition-colors">
                <Linkedin size={16} />
              </a>
              <a href={(info.social?.youtube || COMPANY_INFO.social.youtube)} className="bg-red-600 hover:bg-red-700 w-10 h-10 rounded-lg flex items-center justify-center transition-colors">
                <Youtube size={16} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">Hızlı Linkler</h4>
            <div className="space-y-3">
              {quickLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="block text-gray-400 hover:text-white transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-6">İletişim</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="text-primary mt-1" size={16} />
                <div>
                  <p className="text-gray-400">{info.address}</p>
                  <p className="text-gray-400">{info.city}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="text-primary" size={16} />
                <a href={`tel:${info.phone}`} className="text-gray-400 hover:text-white transition-colors">
                  {info.phone}
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="text-primary" size={16} />
                <a href={`mailto:${info.email}`} className="text-gray-400 hover:text-white transition-colors">
                  {info.email}
                </a>
              </div>
              <div className="flex items-start space-x-3">
                <Clock className="text-primary mt-1" size={16} />
                <div>
                  <p className="text-gray-400">
                    {info.working_hours?.weekdays || info.workingHours?.weekdays || COMPANY_INFO.workingHours.weekdays}
                  </p>
                  <p className="text-gray-400">
                    {info.working_hours?.weekend || info.workingHours?.weekend || COMPANY_INFO.workingHours.weekend}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 ANKAPANJUR - Kepenk & Kapı Sistemleri. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </footer>
  );
}
