import { useState } from "react";
import type { ReactNode } from "react";
import Uppy from "@uppy/core";
import { DashboardModal } from "@uppy/react";
import "@uppy/core/dist/style.min.css";
import "@uppy/dashboard/dist/style.min.css";
import AwsS3 from "@uppy/aws-s3";
import type { UploadResult } from "@uppy/core";
import { Button } from "@/components/ui/button";

interface ImageUploaderProps {
  maxNumberOfFiles?: number;
  maxFileSize?: number;
  onGetUploadParameters: () => Promise<{
    method: "PUT";
    url: string;
  }>;
  onComplete?: (
    result: UploadResult<Record<string, unknown>, Record<string, unknown>>
  ) => void;
  buttonClassName?: string;
  children: ReactNode;
}

/**
 * Resim yükleme komponenti - bir buton şeklinde görünür ve modal ile dosya yönetimi sağlar.
 * 
 * Özellikler:
 * - Özelleştirilebilir buton olarak görünür ve dosya yükleme modalı açar
 * - Modal arayüzü sunar:
 *   - Dosya seçimi
 *   - Dosya önizleme
 *   - Yükleme durumu takibi
 *   - Yükleme sonucu gösterimi
 * 
 * Dosya yönetimi için Uppy kullanır ve tüm dosya yönetimi özellikleri otomatik olarak
 * Uppy dashboard modalı tarafından sağlanır.
 */
export function ImageUploader({
  maxNumberOfFiles = 1,
  maxFileSize = 10485760, // 10MB varsayılan
  onGetUploadParameters,
  onComplete,
  buttonClassName,
  children,
}: ImageUploaderProps) {
  const [showModal, setShowModal] = useState(false);
  const [uppy] = useState(() =>
    new Uppy({
      restrictions: {
        maxNumberOfFiles,
        maxFileSize,
        allowedFileTypes: ['image/*'],
      },
      autoProceed: false,
    })
      .use(AwsS3, {
        shouldUseMultipart: false,
        getUploadParameters: onGetUploadParameters,
      })
      .on("complete", (result) => {
        onComplete?.(result);
        setShowModal(false);
      })
  );

  return (
    <div>
      <Button onClick={() => setShowModal(true)} className={buttonClassName}>
        {children}
      </Button>

      <DashboardModal
        uppy={uppy}
        open={showModal}
        onRequestClose={() => setShowModal(false)}
        proudlyDisplayPoweredByUppy={false}
        locale={{
          strings: {
            closeModal: 'Modalı Kapat',
            dashboardTitle: 'Dosya Yükleyici',
            upload: 'Yükle',
            cancel: 'İptal',
            pause: 'Duraklat',
            resume: 'Devam et',
            done: 'Bitti',
            complete: 'Tamamlandı',
            uploading: 'Yükleniyor',
            retry: 'Tekrar dene',
            uploadFailed: 'Yükleme başarısız',
            paused: 'Duraklatıldı',
            error: 'Hata',
            addMore: 'Daha fazla ekle',
            removeFile: 'Dosyayı kaldır',
            back: 'Geri',
            filesUploadedOfTotal: {
              0: '%{complete}/%{smart_count} dosya yüklendi',
              1: '%{complete}/%{smart_count} dosya yüklendi',
            },
            dataUploadedOfTotal: '%{complete} / %{total}',
            xFilesSelected: {
              0: '%{smart_count} dosya seçildi',
              1: '%{smart_count} dosya seçildi',
            }
          }
        }}
      />
    </div>
  );
}