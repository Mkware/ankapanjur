import { useEffect, useState } from "react";
import Logo from "@/components/Logo";

export default function LoadingScreen() {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFadeOut(true);
    }, 3500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`loading-animation ${fadeOut ? 'fade-out' : ''}`}>
      <div className="text-center">
        <div className="logo-animation mb-6 animate-bounce">
          <div className="transform scale-150">
            <Logo size="xl" className="mx-auto drop-shadow-xl" />
          </div>
        </div>
        <div className="mt-8 flex justify-center">
          <div className="w-16 h-1 bg-white/30 rounded-full overflow-hidden">
            <div className="h-full bg-white rounded-full animate-loading-bar"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
