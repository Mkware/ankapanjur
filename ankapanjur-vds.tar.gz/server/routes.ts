import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { 
  insertContactSubmissionSchema,
  contactSubmissions,
  services,
  insertServiceSchema,
  // projects removed
  companyInfo,
  insertCompanyInfoSchema,
  siteSettings,
  insertSiteSettingsSchema,
  users,
  homepageFeatures,
  aboutValues,
  aboutAchievements
} from "@shared/schema";
import { db } from "./storage";
import { eq, desc } from "drizzle-orm";
import bcrypt from "bcryptjs";
// Removed object storage import - using local file storage now
import multer from "multer";
import path from "path";
import fs from "fs";

// Extend the session interface
declare module 'express-session' {
  interface SessionData {
    userId: string;
  }
}

// Middleware to check authentication
const requireAuth = (req: any, res: any, next: any) => {
  if (!req.session?.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
};

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), 'uploads', 'services');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'service-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Sadece görsel dosyaları yüklenebilir!'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Static file serving for uploads
  app.use('/uploads', (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'public, max-age=31536000');
    next();
  });
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
  
  // File upload endpoint
  app.post('/api/upload', requireAuth, upload.array('images', 5), (req, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'Hiç dosya yüklenmedi' });
      }
      
      const files = req.files as Express.Multer.File[];  
      const fileUrls = files.map(file => `/uploads/services/${file.filename}`);
      
      res.json({ 
        success: true, 
        files: fileUrls,
        count: files.length 
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ error: 'Dosya yükleme hatası' });
    }
  });
  
  // Public API endpoints (no auth required)
  app.get("/api/public/services", async (req, res) => {
    try {
      const result = await db.select().from(services).where(eq(services.isActive, true)).orderBy(services.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  // Projects endpoint removed

  app.get("/api/public/company-info", async (req, res) => {
    try {
      const result = await db.select().from(companyInfo).limit(1);
      res.json(result[0] || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch company info" });
    }
  });

  app.get("/api/public/site-settings", async (req, res) => {
    try {
      const result = await db.select().from(siteSettings).limit(1);
      res.json(result[0] || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch site settings" });
    }
  });

  // Homepage Features
  app.get("/api/public/homepage-features", async (req, res) => {
    try {
      const result = await db.select().from(homepageFeatures).where(eq(homepageFeatures.isActive, true)).orderBy(homepageFeatures.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch homepage features" });
    }
  });

  // About Values
  app.get("/api/public/about-values", async (req, res) => {
    try {
      const result = await db.select().from(aboutValues).where(eq(aboutValues.isActive, true)).orderBy(aboutValues.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch about values" });
    }
  });

  // About Achievements
  app.get("/api/public/about-achievements", async (req, res) => {
    try {
      const result = await db.select().from(aboutAchievements).where(eq(aboutAchievements.isActive, true)).orderBy(aboutAchievements.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch about achievements" });
    }
  });

  // Contact form submission endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      
      // Save to database
      const result = await db.insert(contactSubmissions).values(validatedData).returning();
      
      res.json({ 
        success: true, 
        message: "Form başarıyla gönderildi. En kısa sürede sizinle iletişime geçeceğiz.",
        data: result[0]
      });
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(400).json({ 
        success: false, 
        message: "Form gönderilirken bir hata oluştu. Lütfen bilgilerinizi kontrol edip tekrar deneyin." 
      });
    }
  });

  // Get all contact submissions (Admin only)
  app.get("/api/admin/contacts", requireAuth, async (req, res) => {
    try {
      const result = await db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
      res.json(result);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      res.status(500).json({ error: "Failed to fetch contacts" });
    }
  });

  // SERVICES CRUD
  app.get("/api/admin/services", requireAuth, async (req, res) => {
    try {
      const result = await db.select().from(services).orderBy(services.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  // Service image update endpoint
  app.put("/api/admin/services/:id/images", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { imageURLs } = req.body;
      
      if (!Array.isArray(imageURLs)) {
        return res.status(400).json({ error: "imageURLs must be an array" });
      }

      const result = await db
        .update(services)
        .set({ 
          images: imageURLs,
          updatedAt: new Date() 
        })
        .where(eq(services.id, id))
        .returning();

      res.json({ 
        success: true, 
        service: result[0],
        processedImages: imageURLs.length 
      });
    } catch (error) {
      console.error("Error updating service images:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/admin/services", requireAuth, async (req, res) => {
    try {
      const data = insertServiceSchema.parse(req.body);
      
      // Ensure arrays are properly formatted
      const serviceData = {
        ...data,
        features: Array.isArray(data.features) ? data.features : [],
        applications: Array.isArray(data.applications) ? data.applications : [],
        images: Array.isArray(data.images) ? data.images : [],
      };
      const result = await db.insert(services).values(serviceData).returning();
      res.json(result[0]);
    } catch (error) {
      console.error("Service creation error:", error);
      res.status(400).json({ error: "Invalid service data" });
    }
  });

  app.put("/api/admin/services/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertServiceSchema.parse(req.body);
      const updateData = {
        ...data,
        features: Array.isArray(data.features) ? data.features : [],
        applications: Array.isArray(data.applications) ? data.applications : [],
        images: Array.isArray(data.images) ? data.images : [],
        updatedAt: new Date()
      };
      const result = await db.update(services).set(updateData).where(eq(services.id, id)).returning();
      res.json(result[0]);
    } catch (error) {
      console.error("Service update error:", error);
      res.status(400).json({ error: "Invalid service data" });
    }
  });

  app.delete("/api/admin/services/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await db.delete(services).where(eq(services.id, id));
      res.json({ message: "Service deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete service" });
    }
  });

  // PROJECTS - COMPLETELY REMOVED

  // Object Storage Upload endpoint
  app.post("/api/objects/upload", requireAuth, async (req, res) => {
    try {
      // Local file upload - return a simple success response
      res.json({ uploadURL: '/api/upload' });
    } catch (error) {
      console.error("Error generating upload URL:", error);
      res.status(500).json({ error: "Failed to generate upload URL" });
    }
  });

  // COMPANY INFO
  app.get("/api/admin/company-info", requireAuth, async (req, res) => {
    try {
      const result = await db.select().from(companyInfo).limit(1);
      res.json(result[0] || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch company info" });
    }
  });

  app.put("/api/admin/company-info", requireAuth, async (req, res) => {
    try {
      const data = insertCompanyInfoSchema.parse(req.body);
      const existing = await db.select().from(companyInfo).limit(1);
      
      let result;
      if (existing.length > 0) {
        const updateData = { ...data, updatedAt: new Date() };
        result = await db.update(companyInfo).set(updateData).where(eq(companyInfo.id, existing[0].id)).returning();
      } else {
        result = await db.insert(companyInfo).values(data).returning();
      }
      res.json(result[0]);
    } catch (error) {
      console.error("Company info update error:", error);
      res.status(400).json({ error: "Invalid company info data" });
    }
  });

  // SITE SETTINGS
  app.get("/api/admin/site-settings", requireAuth, async (req, res) => {
    try {
      const result = await db.select().from(siteSettings).limit(1);
      res.json(result[0] || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch site settings" });
    }
  });

  app.put("/api/admin/site-settings", requireAuth, async (req, res) => {
    try {
      const data = insertSiteSettingsSchema.parse(req.body);
      const existing = await db.select().from(siteSettings).limit(1);
      
      let result;
      if (existing.length > 0) {
        const updateData = { ...data, updatedAt: new Date() };
        result = await db.update(siteSettings).set(updateData).where(eq(siteSettings.id, existing[0].id)).returning();
      } else {
        result = await db.insert(siteSettings).values(data).returning();
      }
      res.json(result[0]);
    } catch (error) {
      console.error("Site settings update error:", error);
      res.status(400).json({ error: "Invalid site settings data" });
    }
  });

  // HOMEPAGE FEATURES
  app.get("/api/admin/homepage-features", requireAuth, async (req, res) => {
    try {
      const result = await db.select().from(homepageFeatures).orderBy(homepageFeatures.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch homepage features" });
    }
  });

  app.put("/api/admin/homepage-features/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { title, description, icon } = req.body;
      const updateData = { title, description, icon, updatedAt: new Date() };
      const result = await db.update(homepageFeatures).set(updateData).where(eq(homepageFeatures.id, id)).returning();
      res.json(result[0]);
    } catch (error) {
      console.error("Homepage feature update error:", error);
      res.status(400).json({ error: "Invalid homepage feature data" });
    }
  });

  // ABOUT VALUES
  app.get("/api/admin/about-values", requireAuth, async (req, res) => {
    try {
      const result = await db.select().from(aboutValues).orderBy(aboutValues.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch about values" });
    }
  });

  app.put("/api/admin/about-values/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { title, description, icon } = req.body;
      const updateData = { title, description, icon, updatedAt: new Date() };
      const result = await db.update(aboutValues).set(updateData).where(eq(aboutValues.id, id)).returning();
      res.json(result[0]);
    } catch (error) {
      console.error("About value update error:", error);
      res.status(400).json({ error: "Invalid about value data" });
    }
  });

  // ABOUT ACHIEVEMENTS
  app.get("/api/admin/about-achievements", requireAuth, async (req, res) => {
    try {
      const result = await db.select().from(aboutAchievements).orderBy(aboutAchievements.sortOrder);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch about achievements" });
    }
  });

  app.put("/api/admin/about-achievements/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { title, number, label, description, icon } = req.body;
      const updateData = { title, number, label, description, icon, updatedAt: new Date() };
      const result = await db.update(aboutAchievements).set(updateData).where(eq(aboutAchievements.id, id)).returning();
      res.json(result[0]);
    } catch (error) {
      console.error("About achievement update error:", error);
      res.status(400).json({ error: "Invalid about achievement data" });
    }
  });

  // LOGIN/AUTH ENDPOINTS
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const user = await db.select().from(users).where(eq(users.username, username)).limit(1);
      
      if (user.length === 0) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      const isValidPassword = await bcrypt.compare(password, user[0].password);
      
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      req.session!.userId = user[0].id;
      res.json({ message: "Login successful", user: { id: user[0].id, username: user[0].username } });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    req.session?.destroy(() => {
      res.json({ message: "Logout successful" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (req.session?.userId) {
      try {
        const user = await db.select().from(users).where(eq(users.id, req.session.userId)).limit(1);
        if (user.length > 0) {
          res.json({ user: { id: user[0].id, username: user[0].username } });
        } else {
          res.status(401).json({ error: "User not found" });
        }
      } catch (error) {
        res.status(500).json({ error: "Internal server error" });
      }
    } else {
      res.status(401).json({ error: "Not authenticated" });
    }
  });

  // Local file storage endpoints (replaced object storage)
  // Files are served directly via /uploads/ static endpoint above

  // Projects completely removed from system

  const httpServer = createServer(app);
  return httpServer;
}
