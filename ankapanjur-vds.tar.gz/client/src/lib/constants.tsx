import { DoorOpen, Shield, Camera, Home, Building, Factory, Zap, TreePine, Flame, Car } from "lucide-react";

export const COMPANY_INFO = {
  name: "ANKAPANJUR",
  subtitle: "Kepenk & Kapı Sistemleri",
  phone: "+90 541 406 16 95",
  email: "info@ankapanjur.com",
  address: "Merkez Mahallesi, Sanayi Caddesi No:123",
  city: "Kocaeli / Gebze",
  workingHours: {
    weekdays: "Pazartesi - Cumartesi: 08:00 - 18:00",
    weekend: "Pazar: Kapalı"
  },
  social: {
    facebook: "#",
    instagram: "#",
    linkedin: "#",
    youtube: "#"
  }
};

export const SERVICES = [
  {
    id: 1,
    title: "Panjur Sistemleri",
    description: "AnkaPanjur alüminyum ve PVC panjur sistemleri ile mekanlarınızı koruyun. CE belgeli profil ve 10 yıl garanti",
    icon: Shield as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "residential"
  },
  {
    id: 2,
    title: "Kepenk Sistemleri",
    description: "AnkaPanjur motorlu kepenk sistemleri ile maksimum güvenlik. Otomatik ve manuel seçenekler",
    icon: DoorOpen as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "commercial"
  },
  {
    id: 3,
    title: "Fotoselli Kapı Sistemleri",
    description: "AnkaPanjur fotoselli kapı sistemleri ile temassız, hijyenik ve enerji verimli geçiş çözümleri sunuyoruz",
    icon: Camera as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "commercial"
  },
  {
    id: 4,
    title: "Otomatik Kayar Bahçe Kapısı",
    description: "AnkaPanjur otomatik kayar kapı sistemleri. Uzaktan kumanda ve güvenlik sensörleri",
    icon: Home as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "residential"
  },
  {
    id: 5,
    title: "Seksiyonel Kapı Sistemleri",
    description: "AnkaPanjur seksiyonel kapı sistemleri. Garaj ve endüstriyel alanlar için yalıtımlı çözümler",
    icon: Building as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "industrial"
  },
  {
    id: 6,
    title: "Endüstriyel Kapı Sistemleri",
    description: "AnkaPanjur endüstriyel kapı sistemleri. Ağır hizmet tipi yüksek performans çözümleri",
    icon: Factory as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "industrial"
  },
  {
    id: 7,
    title: "Giyotin Sistemleri",
    description: "AnkaPanjur giyotin sistemleri. Hızlı açılıp kapanan güvenlik çözümleri",
    icon: Zap as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "industrial"
  },
  {
    id: 8,
    title: "Pergole Sistemleri",
    description: "AnkaPanjur pergole sistemleri. Otomatik açılır kapanır tente çözümleri",
    icon: TreePine as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "residential"
  },
  {
    id: 9,
    title: "Yangın Kapıları",
    description: "AnkaPanjur yangın kapıları. TSE belgeli yangın güvenlik standartları uygun çözümler",
    icon: Flame as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "commercial"
  },
  {
    id: 10,
    title: "Kollu Bariyer Sistemleri",
    description: "AnkaPanjur kollu bariyer sistemleri. Otomatik araç kontrol ve güvenlik çözümleri",
    icon: Car as React.ComponentType<{ size?: number }>,
    image: "https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    category: "commercial"
  }
];

// Projects completely removed

export const PRODUCT_TYPES = [
  "Otomatik Kepenk Sistemleri",
  "Endüstriyel Kapı Sistemleri", 
  "Güvenlik Sistemleri",
  "Panjur Sistemleri",
  "Fotoselli Kapı Sistemleri",
  "Seksiyonel Kapı Sistemleri",
  "Pergole Sistemleri",
  "Bariyer Sistemleri",
  "Yangın Kapıları",
  "Giyotin Sistemleri"
];