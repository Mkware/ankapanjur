import { useEffect } from "react";
import { CheckCircle, Eye, Star, Award, Users, Tag } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import OptimizedImage from "@/components/OptimizedImage";
import { useSEO } from "@/hooks/useSEO";

export default function About() {
  // Fetch company info from database
  const { data: companyInfo } = useQuery({
    queryKey: ['/api/public/company-info'],
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['/api/public/site-settings'],
  });

  const { data: valuesFromDB = [] } = useQuery({
    queryKey: ['/api/public/about-values'],
  });

  const { data: achievementsFromDB = [] } = useQuery({
    queryKey: ['/api/public/about-achievements'],
  });

  // SEO setup
  useSEO({
    title: `Hakkımızda | ${siteSettings?.siteName || "AnkaPanjur"}`,
    description: companyInfo?.aboutText || "AnkaPanjur olarak 10 yıldır otomasyon sektöründe faaliyet gösteriyoruz. Kaliteli malzeme ve profesyonel montaj ile sizlere hizmet veriyoruz.",
    keywords: siteSettings?.metaKeywords || "hakkımızda, ankapanjur, otomasyon, kepenk, kalite, tecrübe"
  });

  // Get icon component from name
  const getIconComponent = (iconName: string) => {
    const icons: Record<string, any> = {
      CheckCircle, Eye, Star, Award, Users, Tag
    };
    return icons[iconName] || CheckCircle;
  };

  const values = (valuesFromDB as any[]).map((value: any) => ({
    icon: getIconComponent(value.icon),
    title: value.title,
    description: value.description
  }));

  const achievements = (achievementsFromDB as any[]).map((achievement: any) => ({
    icon: getIconComponent(achievement.icon),
    number: achievement.number,
    label: achievement.label,
    description: achievement.description
  }));

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-display font-bold mb-6">Hakkımızda</h1>
            <p className="text-xl max-w-3xl mx-auto text-blue-50 font-medium">
              25 yıllık deneyimimizle Türkiye'nin önde gelen otomasyon kepenk ve kapı sistemleri üreticisiyiz
            </p>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">Firma Hikayemiz</h2>
              <div className="space-y-6 text-gray-600 leading-relaxed">
                <p>
                  1998 yılında kurulduğumuzdan bu yana, otomasyon kepenk ve kapı sistemleri sektöründe 
                  kalite ve güvenilirlik standartlarını belirlemeye devam ediyoruz. İlk günden itibaren 
                  müşteri memnuniyetini önceleyerek, sektörde öncü konumumuzu koruyoruz.
                </p>
                <p>
                  Teknolojik gelişmeleri yakından takip ederek, ürün gamımızı sürekli genişletiyoruz. 
                  Endüstriyel kapılardan konut güvenlik sistemlerine kadar geniş bir yelpazede hizmet 
                  vermekteyiz.
                </p>
                <p>
                  Bugün 81 ilde hizmet veren güçlü bayi ağımız, deneyimli teknik ekibimiz ve 
                  7/24 müşteri desteğimizle sektörün lider firmalarından biri konumundayız.
                </p>
              </div>
            </div>
            
            <div className="relative">
              <OptimizedImage 
                src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Şirket binası ve ekibimiz" 
                className="rounded-2xl shadow-xl w-full h-auto" 
                width={800}
                height={600}
                priority={true}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Misyon, Vizyon ve Değerlerimiz</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Güçlü değerlerimiz ve net vizyonumuzla sektörde öncü olmaya devam ediyoruz
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg text-center">
                <div className="bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <value.icon size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Başarılarımız</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Çeyrek asırlık deneyimimizin getirdiği güven ve başarılarımız
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center p-8 bg-gray-50 rounded-xl">
                <div className="bg-accent text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <achievement.icon size={24} />
                </div>
                <div className="text-4xl font-bold text-primary mb-2">{achievement.number}</div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">{achievement.label}</h3>
                <p className="text-gray-600">{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Uzman Ekibimiz</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Deneyimli ve uzman kadromuzla her projeye profesyonel çözümler sunuyoruz
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h3 className="text-3xl font-bold text-gray-800 mb-6">Profesyonel Kadromuz</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-gray-800">Teknik Ekip</h4>
                    <p className="text-gray-600">Sektörde uzun yıllar deneyim sahibi teknik uzmanlarımız</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-primary text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-gray-800">Satış Danışmanları</h4>
                    <p className="text-gray-600">Müşteri ihtiyaçlarını anlayan deneyimli satış ekibimiz</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-primary text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-gray-800">Montaj Ekipleri</h4>
                    <p className="text-gray-600">Profesyonel montaj hizmeti sunan sertifikalı teknisyenlerimiz</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-primary text-white w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle size={16} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-gray-800">Müşteri Hizmetleri</h4>
                    <p className="text-gray-600">7/24 destek sağlayan müşteri hizmetleri ekibimiz</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Çalışan ekibimiz" 
                className="rounded-2xl shadow-xl w-full h-auto" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Certificates */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Sertifikalar ve Ödüller</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Kalite standartlarımızı belgeleyen uluslararası sertifikalarımız
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Tag size={24} />
              </div>
              <h3 className="font-bold text-gray-800 mb-2">ISO 9001</h3>
              <p className="text-gray-600 text-sm">Kalite Yönetim Sistemi</p>
            </div>
            
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-green-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Tag size={24} />
              </div>
              <h3 className="font-bold text-gray-800 mb-2">TSE Belgesi</h3>
              <p className="text-gray-600 text-sm">Türk Standartları Enstitüsü</p>
            </div>
            
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Tag size={24} />
              </div>
              <h3 className="font-bold text-gray-800 mb-2">CE Belgesi</h3>
              <p className="text-gray-600 text-sm">Avrupa Uygunluk Belgesi</p>
            </div>
            
            <div className="text-center p-6 bg-gray-50 rounded-xl">
              <div className="bg-red-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award size={24} />
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Kalite Ödülü</h3>
              <p className="text-gray-600 text-sm">Sektör Mükemmellik Ödülü</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
