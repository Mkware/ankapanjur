import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Settings, 
  Users, 
  FileText, 
  MessageSquare, 
  Building2, 
  LogOut,
  Shield,
  DoorOpen,
  Camera,
  Home,
  Factory,
  Zap,
  TreePine,
  Flame,
  Car,
  Plus,
  Edit,
  Trash2,
  Save
} from "lucide-react";
import OptimizedImage from "@/components/OptimizedImage";
import { SimpleImageUploader } from "@/components/SimpleImageUploader";

export default function Admin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("dashboard");

  // Data states
  const [contacts, setContacts] = useState([]);
  const [services, setServices] = useState([]);
  // Projects removed
  const [companyInfo, setCompanyInfo] = useState<any>(null);
  const [siteSettings, setSiteSettings] = useState<any>(null);
  const [homepageFeatures, setHomepageFeatures] = useState([]);
  const [aboutValues, setAboutValues] = useState([]);
  const [aboutAchievements, setAboutAchievements] = useState([]);

  // Form states
  const [editingService, setEditingService] = useState<any>(null);
  // Project editing removed
  const [editingFeature, setEditingFeature] = useState<any>(null);
  const [editingValue, setEditingValue] = useState<any>(null);
  const [editingAchievement, setEditingAchievement] = useState<any>(null);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const response = await fetch("/api/auth/me");
      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
        loadData();
      } else {
        setLocation("/admin/login");
      }
    } catch (error) {
      setLocation("/admin/login");
    } finally {
      setLoading(false);
    }
  };

  const loadData = async () => {
    try {
      const [contactsRes, servicesRes, companyRes, settingsRes, featuresRes, valuesRes, achievementsRes] = await Promise.all([
        fetch("/api/admin/contacts"),
        fetch("/api/admin/services"),
        fetch("/api/admin/company-info"),
        fetch("/api/admin/site-settings"),
        fetch("/api/admin/homepage-features"),
        fetch("/api/admin/about-values"),
        fetch("/api/admin/about-achievements")
      ]);

      if (contactsRes.ok) setContacts(await contactsRes.json());
      if (servicesRes.ok) setServices(await servicesRes.json());
      if (companyRes.ok) setCompanyInfo(await companyRes.json());
      if (settingsRes.ok) setSiteSettings(await settingsRes.json());
      if (featuresRes.ok) setHomepageFeatures(await featuresRes.json());
      if (valuesRes.ok) setAboutValues(await valuesRes.json());
      if (achievementsRes.ok) setAboutAchievements(await achievementsRes.json());
    } catch (error) {
      toast({
        title: "Hata",
        description: "Veriler yüklenirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      setLocation("/admin/login");
    } catch (error) {
      toast({
        title: "Hata",
        description: "Çıkış yapılırken hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleServiceSave = async (serviceData: any) => {
    try {
      const method = editingService?.id ? "PUT" : "POST";
      const url = editingService?.id ? `/api/admin/services/${editingService.id}` : "/api/admin/services";
      
      const response = await apiRequest(method, url, serviceData);

      if (response.ok) {
        toast({
          title: "Başarılı",
          description: editingService?.id ? "Hizmet güncellendi" : "Hizmet eklendi"
        });
        setEditingService(null);
        loadData();
      }
    } catch (error) {
      console.error("Service save error:", error);
      toast({
        title: "Hata",
        description: "Hizmet kaydedilirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleServiceDelete = async (id: string) => {
    if (!confirm("Bu hizmeti silmek istediğinizden emin misiniz?")) return;
    
    try {
      const response = await fetch(`/api/admin/services/${id}`, { method: "DELETE" });
      if (response.ok) {
        toast({
          title: "Başarılı",
          description: "Hizmet silindi"
        });
        loadData();
      }
    } catch (error) {
      toast({
        title: "Hata",
        description: "Hizmet silinirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  // Project functions removed

  const handleCompanyInfoSave = async (data: any) => {
    try {
      const response = await apiRequest("PUT", "/api/admin/company-info", data);

      if (response.ok) {
        toast({
          title: "Başarılı",
          description: "Şirket bilgileri güncellendi"
        });
        loadData();
      }
    } catch (error) {
      toast({
        title: "Hata",
        description: "Şirket bilgileri güncellenirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleSiteSettingsSave = async (data: any) => {
    try {
      const response = await apiRequest("PUT", "/api/admin/site-settings", data);

      if (response.ok) {
        toast({
          title: "Başarılı",
          description: "Site ayarları güncellendi"
        });
        loadData();
      }
    } catch (error) {
      toast({
        title: "Hata",
        description: "Site ayarları güncellenirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleFeatureSave = async (featureData: any) => {
    try {
      const response = await apiRequest("PUT", `/api/admin/homepage-features/${editingFeature?.id}`, featureData);

      if (response.ok) {
        toast({
          title: "Başarılı",
          description: "Ana sayfa özelliği güncellendi"
        });
        setEditingFeature(null);
        loadData();
      }
    } catch (error) {
      console.error("Feature save error:", error);
      toast({
        title: "Hata",
        description: "Özellik kaydedilirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleValueSave = async (valueData: any) => {
    try {
      const response = await apiRequest("PUT", `/api/admin/about-values/${editingValue?.id}`, valueData);

      if (response.ok) {
        toast({
          title: "Başarılı",
          description: "Hakkımızda değeri güncellendi"
        });
        setEditingValue(null);
        loadData();
      }
    } catch (error) {
      console.error("Value save error:", error);
      toast({
        title: "Hata",
        description: "Değer kaydedilirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  const handleAchievementSave = async (achievementData: any) => {
    try {
      const response = await apiRequest("PUT", `/api/admin/about-achievements/${editingAchievement?.id}`, achievementData);

      if (response.ok) {
        toast({
          title: "Başarılı",
          description: "Başarı güncellendi"
        });
        setEditingAchievement(null);
        loadData();
      }
    } catch (error) {
      console.error("Achievement save error:", error);
      toast({
        title: "Hata",
        description: "Başarı kaydedilirken hata oluştu",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Yükleniyor...</div>;
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Building2 className="h-8 w-8 text-primary" />
              <h1 className="text-xl font-bold text-gray-900">AnkaPanjur Admin</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Hoş geldin, {user.username}</span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Çıkış
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="contacts">Mesajlar</TabsTrigger>
            <TabsTrigger value="services">Hizmetler</TabsTrigger>
            {/* Projects tab removed */}
            <TabsTrigger value="texts">Yazılar</TabsTrigger>
            <TabsTrigger value="content">İçerik</TabsTrigger>
            <TabsTrigger value="company">Şirket</TabsTrigger>
            <TabsTrigger value="settings">Ayarlar</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Toplam Mesaj</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{contacts.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Aktif Hizmetler</CardTitle>
                  <Settings className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{services.filter((s: any) => s.isActive).length}</div>
                </CardContent>
              </Card>
              {/* Project card removed */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Sistem Durumu</CardTitle>
                  <Shield className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">Aktif</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="contacts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Gelen Mesajlar</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {contacts.map((contact: any) => (
                    <div key={contact.id} className="border p-4 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold">{contact.fullName}</h3>
                          <p className="text-sm text-gray-600">{contact.phone} • {contact.email}</p>
                        </div>
                        <span className="text-xs text-gray-500">
                          {new Date(contact.createdAt).toLocaleDateString('tr-TR')}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 mb-2">{contact.message}</p>
                      {contact.productType && (
                        <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                          {contact.productType}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="services" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">Hizmetler</h2>
              <Button onClick={() => setEditingService({})}>
                <Plus className="h-4 w-4 mr-2" />
                Yeni Hizmet
              </Button>
            </div>
            
            <div className="grid gap-4">
              {services.map((service: any) => (
                <Card key={service.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">{service.title}</h3>
                        <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                        <div className="flex items-center mt-2 space-x-2">
                          <span className={`px-2 py-1 text-xs rounded ${service.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                            {service.isActive ? 'Aktif' : 'Pasif'}
                          </span>
                          <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">
                            {service.category}
                          </span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => setEditingService(service)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleServiceDelete(service.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Projects tab content removed */}

          <TabsContent value="texts" className="space-y-6">
            <TextsManagement 
              homepageFeatures={homepageFeatures}
              aboutValues={aboutValues}
              aboutAchievements={aboutAchievements}
              onFeatureEdit={setEditingFeature}
              onValueEdit={setEditingValue}
              onAchievementEdit={setEditingAchievement}
              editingFeature={editingFeature}
              editingValue={editingValue}
              editingAchievement={editingAchievement}
              onFeatureSave={handleFeatureSave}
              onValueSave={handleValueSave}
              onAchievementSave={handleAchievementSave}
              onFeatureCancel={() => setEditingFeature(null)}
              onValueCancel={() => setEditingValue(null)}
              onAchievementCancel={() => setEditingAchievement(null)}
            />
          </TabsContent>

          <TabsContent value="content" className="space-y-6">
            <ContentManagement 
              services={services}
              onServiceUpdate={loadData}
            />
          </TabsContent>

          <TabsContent value="company" className="space-y-6">
            <CompanyInfoForm 
              data={companyInfo} 
              onSave={handleCompanyInfoSave} 
            />
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <SiteSettingsForm 
              data={siteSettings} 
              onSave={handleSiteSettingsSave} 
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Modals */}
      {editingService !== null && (
        <ServiceModal 
          service={editingService} 
          onSave={handleServiceSave}
          onClose={() => setEditingService(null)}
        />
      )}

      {/* Project modal removed */}
    </div>
  );
}

// Company Info Form Component
function CompanyInfoForm({ data, onSave }: { data: any, onSave: (data: any) => void }) {
  const [formData, setFormData] = useState(data || {
    name: "",
    subtitle: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    workingHours: { weekdays: "", weekend: "" },
    social: {},
    aboutText: "",
    missionText: "",
    visionText: ""
  });

  useEffect(() => {
    if (data) setFormData(data);
  }, [data]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Şirket Bilgileri</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Şirket Adı</Label>
              <Input
                id="name"
                value={formData.name || ""}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="subtitle">Alt Başlık</Label>
              <Input
                id="subtitle"
                value={formData.subtitle || ""}
                onChange={(e) => setFormData({...formData, subtitle: e.target.value})}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Telefon</Label>
              <Input
                id="phone"
                value={formData.phone || ""}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
              />
            </div>
            <div>
              <Label htmlFor="email">E-posta</Label>
              <Input
                id="email"
                type="email"
                value={formData.email || ""}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="address">Adres</Label>
            <Input
              id="address"
              value={formData.address || ""}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
            />
          </div>

          <div>
            <Label htmlFor="city">Şehir</Label>
            <Input
              id="city"
              value={formData.city || ""}
              onChange={(e) => setFormData({...formData, city: e.target.value})}
            />
          </div>

          <div>
            <Label htmlFor="aboutText">Ana Açıklama (Hakkımızda)</Label>
            <textarea
              id="aboutText"
              className="w-full min-h-[80px] p-3 border border-gray-300 rounded-md resize-vertical"
              value={formData.aboutText || ""}
              onChange={(e) => setFormData({...formData, aboutText: e.target.value})}
              placeholder="25 yıllık deneyimimizle Türkiye'nin önde gelen..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="missionText">Misyon</Label>
              <textarea
                id="missionText"
                className="w-full min-h-[60px] p-3 border border-gray-300 rounded-md resize-vertical"
                value={formData.missionText || ""}
                onChange={(e) => setFormData({...formData, missionText: e.target.value})}
                placeholder="Misyon metni..."
              />
            </div>
            <div>
              <Label htmlFor="visionText">Vizyon</Label>
              <textarea
                id="visionText"
                className="w-full min-h-[60px] p-3 border border-gray-300 rounded-md resize-vertical"
                value={formData.visionText || ""}
                onChange={(e) => setFormData({...formData, visionText: e.target.value})}
                placeholder="Vizyon metni..."
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="weekdays">Hafta İçi Çalışma Saatleri</Label>
              <Input
                id="weekdays"
                value={formData.workingHours?.weekdays || ""}
                onChange={(e) => setFormData({
                  ...formData, 
                  workingHours: {
                    ...formData.workingHours,
                    weekdays: e.target.value
                  }
                })}
                placeholder="Pazartesi - Cumartesi: 08:00 - 18:00"
              />
            </div>
            <div>
              <Label htmlFor="weekend">Pazar Günü Çalışma Saatleri</Label>
              <Input
                id="weekend"
                value={formData.workingHours?.weekend || ""}
                onChange={(e) => setFormData({
                  ...formData, 
                  workingHours: {
                    ...formData.workingHours,
                    weekend: e.target.value
                  }
                })}
                placeholder="Kapalı veya 10:00 - 16:00"
              />
            </div>
          </div>

          <Button type="submit" className="w-full">
            <Save className="h-4 w-4 mr-2" />
            Kaydet
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

// Site Settings Form Component
function SiteSettingsForm({ data, onSave }: { data: any, onSave: (data: any) => void }) {
  const [formData, setFormData] = useState(data || {
    siteName: "",
    siteDescription: "",
    heroTitle: "",
    heroSubtitle: "",
    heroButtonText: "",
    heroImage: "",
    aboutTitle: "",
    aboutDescription: "",
    servicesTitle: "",
    servicesDescription: "",
    contactTitle: "",
    contactDescription: "",
    metaKeywords: ""
  });

  useEffect(() => {
    if (data) setFormData(data);
  }, [data]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Site Ayarları</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="siteName">Site Adı</Label>
            <Input
              id="siteName"
              value={formData.siteName || ""}
              onChange={(e) => setFormData({...formData, siteName: e.target.value})}
            />
          </div>

          <div>
            <Label htmlFor="heroTitle">Ana Sayfa Başlık</Label>
            <Input
              id="heroTitle"
              value={formData.heroTitle || ""}
              onChange={(e) => setFormData({...formData, heroTitle: e.target.value})}
            />
          </div>

          <div>
            <Label htmlFor="heroSubtitle">Ana Sayfa Alt Başlık</Label>
            <Input
              id="heroSubtitle"
              value={formData.heroSubtitle || ""}
              onChange={(e) => setFormData({...formData, heroSubtitle: e.target.value})}
            />
          </div>

          <div>
            <Label>Ana Sayfa Hero Görseli</Label>
            <div className="space-y-2">
              {formData.heroImage && (
                <div className="relative">
                  <img 
                    src={formData.heroImage} 
                    alt="Hero görsel önizleme" 
                    className="w-full h-32 object-cover rounded-lg border"
                  />
                </div>
              )}
              <SimpleImageUploader
                onUpload={(urls) => {
                  if (urls.length > 0) {
                    setFormData({...formData, heroImage: urls[0]});
                  }
                }}
                maxFiles={1}
                className="w-full"
              >
                Hero Görseli Yükle
              </SimpleImageUploader>
              <p className="text-sm text-gray-500">Ana sayfada büyük görsel olarak gösterilecek resmi yükleyin</p>
            </div>
          </div>

          <div>
            <Label htmlFor="servicesTitle">Hizmetler Başlığı</Label>
            <Input
              id="servicesTitle"
              value={formData.servicesTitle || ""}
              onChange={(e) => setFormData({...formData, servicesTitle: e.target.value})}
            />
          </div>

          <div>
            <Label htmlFor="siteDescription">Site Açıklaması (Meta Description)</Label>
            <textarea
              id="siteDescription"
              className="w-full p-2 border rounded-md"
              rows={3}
              value={formData.siteDescription || ""}
              onChange={(e) => setFormData({...formData, siteDescription: e.target.value})}
              placeholder="Site açıklamanızı girin (Google'da görünecek açıklama)"
            />
            <p className="text-sm text-gray-500 mt-1">Arama motorlarında gösterilecek site açıklaması (150-160 karakter önerilir)</p>
          </div>

          <div>
            <Label htmlFor="metaKeywords">SEO Anahtar Kelimeler</Label>
            <textarea
              id="metaKeywords"
              className="w-full p-2 border rounded-md"
              rows={2}
              value={formData.metaKeywords || ""}
              onChange={(e) => setFormData({...formData, metaKeywords: e.target.value})}
              placeholder="otomasyon, kepenk, kapı, güvenlik, ankara, panjur"
            />
            <p className="text-sm text-gray-500 mt-1">Virgülle ayırarak anahtar kelimeleri girin</p>
          </div>

          <Button type="submit" className="w-full">
            <Save className="h-4 w-4 mr-2" />
            Kaydet
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

// Texts Management Component
function TextsManagement({ 
  homepageFeatures,
  aboutValues,
  aboutAchievements,
  onFeatureEdit,
  onValueEdit,
  onAchievementEdit,
  editingFeature,
  editingValue,
  editingAchievement,
  onFeatureSave,
  onValueSave,
  onAchievementSave,
  onFeatureCancel,
  onValueCancel,
  onAchievementCancel
}: any) {
  return (
    <div className="space-y-6">
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Homepage Features */}
        <Card>
          <CardHeader>
            <CardTitle>Ana Sayfa Özellikleri ({homepageFeatures.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-96 overflow-y-auto">
            {homepageFeatures.map((feature: any) => (
              <div key={feature.id} className="p-3 border rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-sm">{feature.title}</h4>
                    <p className="text-xs text-gray-600 mt-1 line-clamp-2">{feature.description.substring(0, 80)}...</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onFeatureEdit(feature)}
                    className="ml-2"
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* About Values */}
        <Card>
          <CardHeader>
            <CardTitle>Hakkımızda Değerleri ({aboutValues.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-96 overflow-y-auto">
            {aboutValues.map((value: any) => (
              <div key={value.id} className="p-3 border rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-sm">{value.title}</h4>
                    <p className="text-xs text-gray-600 mt-1 line-clamp-2">{value.description}</p>
                  </div>
                  <Button
                    variant="outline"  
                    size="sm"
                    onClick={() => onValueEdit(value)}
                    className="ml-2"
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* About Achievements */}
        <Card>
          <CardHeader>
            <CardTitle>Hakkımızda Başarıları ({aboutAchievements.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-96 overflow-y-auto">
            {aboutAchievements.map((achievement: any) => (
              <div key={achievement.id} className="p-3 border rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-sm">{achievement.title}</h4>
                    <p className="text-xs text-gray-600 mt-1">{achievement.number} - {achievement.label}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onAchievementEdit(achievement)}
                    className="ml-2"
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Edit Forms */}
      {editingFeature && (
        <Card>
          <CardHeader>
            <CardTitle>Ana Sayfa Özelliği Düzenle</CardTitle>
          </CardHeader>
          <CardContent>
            <TextEditForm
              data={editingFeature}
              onSave={onFeatureSave}
              onCancel={onFeatureCancel}
              fields={[
                { name: 'title', label: 'Başlık', type: 'text' },
                { name: 'description', label: 'Açıklama', type: 'textarea' },
                { name: 'icon', label: 'İkon Adı', type: 'text', placeholder: 'Calendar, Users, Star vb.' }
              ]}
            />
          </CardContent>
        </Card>
      )}

      {editingValue && (
        <Card>
          <CardHeader>
            <CardTitle>Hakkımızda Değeri Düzenle</CardTitle>
          </CardHeader>
          <CardContent>
            <TextEditForm
              data={editingValue}
              onSave={onValueSave}
              onCancel={onValueCancel}
              fields={[
                { name: 'title', label: 'Başlık', type: 'text' },
                { name: 'description', label: 'Açıklama', type: 'textarea' },
                { name: 'icon', label: 'İkon Adı', type: 'text', placeholder: 'CheckCircle, Eye, Star vb.' }
              ]}
            />
          </CardContent>
        </Card>
      )}

      {editingAchievement && (
        <Card>
          <CardHeader>
            <CardTitle>Hakkımızda Başarısı Düzenle</CardTitle>
          </CardHeader>
          <CardContent>
            <TextEditForm
              data={editingAchievement}
              onSave={onAchievementSave}
              onCancel={onAchievementCancel}
              fields={[
                { name: 'title', label: 'Başlık', type: 'text' },
                { name: 'number', label: 'Sayı/Değer', type: 'text' },
                { name: 'label', label: 'Etiket', type: 'text' },
                { name: 'description', label: 'Açıklama', type: 'text' },
                { name: 'icon', label: 'İkon Adı', type: 'text', placeholder: 'Award, Users, Tag vb.' }
              ]}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Generic Text Edit Form Component
function TextEditForm({ data, onSave, onCancel, fields }: any) {
  const [formData, setFormData] = useState(data);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {fields.map((field: any) => (
        <div key={field.name}>
          <Label htmlFor={field.name}>{field.label}</Label>
          {field.type === 'textarea' ? (
            <textarea
              id={field.name}
              className="w-full p-2 border rounded-md min-h-[100px]"
              value={formData[field.name] || ""}
              onChange={(e) => setFormData({...formData, [field.name]: e.target.value})}
              placeholder={field.placeholder}
            />
          ) : (
            <Input
              id={field.name}
              type={field.type}
              value={formData[field.name] || ""}
              onChange={(e) => setFormData({...formData, [field.name]: e.target.value})}
              placeholder={field.placeholder}
            />
          )}
        </div>
      ))}
      
      <div className="flex space-x-2">
        <Button type="submit">
          <Save className="h-4 w-4 mr-2" />
          Kaydet
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          İptal
        </Button>
      </div>
    </form>
  );
}

// Content Management Component
function ContentManagement({ services, onServiceUpdate }: { 
  services: any[], 
  onServiceUpdate: () => void
}) {
  const [editingContent, setEditingContent] = useState<any>(null);

  const handleContentSave = async (data: any) => {
    try {
      const endpoint = editingContent?.id ? `/api/admin/services/${editingContent.id}` : "/api/admin/services";
      const method = editingContent?.id ? "PUT" : "POST";
      
      const response = await fetch(endpoint, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });

      if (response.ok) {
        setEditingContent(null);
        onServiceUpdate();
      }
    } catch (error) {
      console.error("Content save error:", error);
    }
  };

  const handleContentDelete = async (id: string) => {
    if (!confirm("Bu hizmeti silmek istediğinizden emin misiniz?")) return;
    
    try {
      const response = await fetch(`/api/admin/services/${id}`, { method: "DELETE" });
      
      if (response.ok) {
        onServiceUpdate();
      }
    } catch (error) {
      console.error("Content delete error:", error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">İçerik Yönetimi</h2>
        <div className="space-x-2">
          <Button onClick={() => setEditingContent({ type: 'service' })}>
            <Plus className="h-4 w-4 mr-2" />
            Yeni Hizmet
          </Button>
          {/* New Project button removed */}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Hizmetler ({services.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-96 overflow-y-auto">
            {services.map((service: any) => (
              <div key={service.id} className="flex justify-between items-center p-2 border rounded">
                <div>
                  <span className="font-medium">{service.title}</span>
                  <span className={`ml-2 px-2 py-1 text-xs rounded ${service.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {service.isActive ? 'Aktif' : 'Pasif'}
                  </span>
                </div>
                <div className="space-x-1">
                  <Button variant="outline" size="sm" onClick={() => setEditingContent({...service, type: 'service'})}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleContentDelete(service.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Projects card removed */}
      </div>

      {editingContent && (
        <ContentModal 
          content={editingContent} 
          onSave={handleContentSave}
          onClose={() => setEditingContent(null)}
        />
      )}
    </div>
  );
}

// Content Modal Component (Universal for Services and Projects)
function ContentModal({ content, onSave, onClose }: { content: any, onSave: (data: any) => void, onClose: () => void }) {
  const isService = content.type === 'service' || content.features !== undefined;
  const [formData, setFormData] = useState(content.id ? content : {
    title: "",
    description: "",
    category: "residential",
    isActive: true,
    sortOrder: 0,
    ...(isService ? {
      features: [],
      applications: [],
      technicalSpecs: {},
      images: []
    } : {
      image: "",
      location: ""
    })
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const { type, ...dataToSave } = formData;
    onSave(dataToSave);
  };

  const handleArrayFieldChange = (field: string, value: string) => {
    const items = value.split('\n').filter(item => item.trim());
    setFormData({...formData, [field]: items});
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-screen overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">
            {content?.id ? `${isService ? 'Hizmet' : 'Proje'} Düzenle` : `Yeni ${isService ? 'Hizmet' : 'Proje'}`}
          </h3>
          <Button variant="ghost" onClick={onClose}>×</Button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="title">Başlık</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                required
              />
            </div>
            <div>
              <Label htmlFor="category">Kategori</Label>
              <select
                id="category"
                className="w-full p-2 border rounded-md"
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
              >
                <option value="residential">Konut</option>
                <option value="commercial">Ticari</option>
                <option value="industrial">Endüstriyel</option>
                <option value="security">Güvenlik</option>
              </select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Açıklama</Label>
            <textarea
              id="description"
              className="w-full p-2 border rounded-md"
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              required
            />
          </div>

          {!isService && (
            <>
              <div>
                <Label htmlFor="image">Görsel URL</Label>
                <Input
                  id="image"
                  value={formData.image}
                  onChange={(e) => setFormData({...formData, image: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="location">Konum</Label>
                <Input
                  id="location"
                  value={formData.location || ""}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                />
              </div>
            </>
          )}

          {isService && (
            <>
              <div>
                <Label htmlFor="features">Özellikler (Her satıra bir özellik)</Label>
                <textarea
                  id="features"
                  className="w-full p-2 border rounded-md"
                  rows={4}
                  value={Array.isArray(formData.features) ? formData.features.join('\n') : ''}
                  onChange={(e) => handleArrayFieldChange('features', e.target.value)}
                  placeholder="Alüminyum profil kepenk lamaları&#10;RF uzaktan kumanda sistemi&#10;Sessiz çalışan tubular motor"
                />
              </div>
              <div>
                <Label htmlFor="applications">Uygulama Alanları (Her satıra bir alan)</Label>
                <textarea
                  id="applications"
                  className="w-full p-2 border rounded-md"
                  rows={3}
                  value={Array.isArray(formData.applications) ? formData.applications.join('\n') : ''}
                  onChange={(e) => handleArrayFieldChange('applications', e.target.value)}
                  placeholder="Konut balkon ve terrasları&#10;Cafe ve restoran cepheleri&#10;Ofis binaları"
                />
              </div>
              <div>
                <Label htmlFor="images">Görsel URL'leri (Her satıra bir URL)</Label>
                <textarea
                  id="images"
                  className="w-full p-2 border rounded-md"
                  rows={2}
                  value={Array.isArray(formData.images) ? formData.images.join('\n') : ''}
                  onChange={(e) => handleArrayFieldChange('images', e.target.value)}
                  placeholder="https://images.unsplash.com/photo-1..."
                />
              </div>
            </>
          )}

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isActive"
                checked={formData.isActive}
                onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              />
              <Label htmlFor="isActive">Aktif</Label>
            </div>
            <div>
              <Label htmlFor="sortOrder">Sıralama</Label>
              <Input
                id="sortOrder"
                type="number"
                value={formData.sortOrder}
                onChange={(e) => setFormData({...formData, sortOrder: parseInt(e.target.value) || 0})}
                className="w-20"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              İptal
            </Button>
            <Button type="submit">
              Kaydet
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Service Modal Component
function ServiceModal({ service, onSave, onClose }: { service: any, onSave: (data: any) => void, onClose: () => void }) {
  const { toast } = useToast();
  const [formData, setFormData] = useState(service || {
    title: "",
    description: "",
    features: [],
    applications: [],
    technicalSpecs: {},
    images: [],
    category: "",
    isActive: true,
    sortOrder: 0
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // If this is an existing service with uploaded images, process them
    if (formData.id && Array.isArray(formData.images) && formData.images.length > 0) {
      try {
        const response = await fetch(`/api/admin/services/${formData.id}/images`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ imageURLs: formData.images })
        });
        
        if (response.ok) {
          const data = await response.json();
          formData.images = data.service.images;
        }
      } catch (error) {
        console.error("Error processing service images:", error);
      }
    }
    
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-screen overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">
            {service?.id ? 'Hizmet Düzenle' : 'Yeni Hizmet'}
          </h3>
          <Button variant="ghost" onClick={onClose}>×</Button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="title">Başlık</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Açıklama</Label>
            <textarea
              id="description"
              className="w-full p-2 border rounded-md"
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              required
            />
          </div>

          <div>
            <Label htmlFor="images">Hizmet Görselleri</Label>
            <div className="space-y-2">
              <SimpleImageUploader
                maxFiles={5}
                onUpload={(urls: string[]) => {
                  const currentImages = Array.isArray(formData.images) ? formData.images : [];
                  setFormData(prevData => ({
                    ...prevData, 
                    images: [...currentImages, ...urls]
                  }));
                  toast({ title: "Görseller yüklendi!", description: `${urls.length} görsel başarıyla yüklendi.` });
                }}
                className="w-full"
              >
                📁 Görsel Yükle (Çoklu)
              </SimpleImageUploader>
              <div className="text-sm text-gray-500">
                Mevcut görseller: {Array.isArray(formData.images) ? formData.images.length : 0}
              </div>
              {Array.isArray(formData.images) && formData.images.length > 0 && (
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {formData.images.map((image, index) => (
                    <div key={index} className="relative">
                      <OptimizedImage
                        src={image}
                        alt={`Hizmet görseli ${index + 1}`}
                        className="w-full h-20 object-cover rounded"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const newImages = formData.images.filter((_: any, i: number) => i !== index);
                          setFormData(prevData => ({...prevData, images: newImages}));
                        }}
                        className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-600"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="category">Kategori</Label>
            <select
              id="category"
              className="w-full p-2 border rounded-md"
              value={formData.category}
              onChange={(e) => setFormData({...formData, category: e.target.value})}
              required
            >
              <option value="">Kategori seçin</option>
              <option value="residential">Konut</option>
              <option value="commercial">Ticari</option>
              <option value="industrial">Endüstriyel</option>
            </select>
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              İptal
            </Button>
            <Button type="submit">
              Kaydet
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ProjectModal component removed