import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, MessageCircle, Phone, Mail, MapPin, Clock, CheckCircle, Star, Users } from "lucide-react";
import { COMPANY_INFO } from "@/lib/constants";
import OptimizedImage from "@/components/OptimizedImage";
import { useSEO } from "@/hooks/useSEO";
import { useQuery } from "@tanstack/react-query";

export default function ServiceDetail() {
  const [, setLocation] = useLocation();
  const [service, setService] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Fetch company info from database
  const { data: companyInfo } = useQuery({
    queryKey: ['/api/public/company-info'],
  });
  
  // Get service from URL params or state
  const urlParams = new URLSearchParams(window.location.search);
  const serviceTitle = urlParams.get('service') || 'Hizmet Bulunamadı';

  // Fetch service data from database
  useEffect(() => {
    const fetchService = async () => {
      try {
        const response = await fetch('/api/public/services');
        const services = await response.json();
        const foundService = services.find((s: any) => s.title === serviceTitle);
        
        if (foundService) {
          setService(foundService);
        } else {
          // Fallback to static data if not found in database
          setService(getServiceDetails(serviceTitle));
        }
      } catch (error) {
        console.error('Error fetching service:', error);
        // Fallback to static data on error
        setService(getServiceDetails(serviceTitle));
      } finally {
        setLoading(false);
      }
    };

    fetchService();
  }, [serviceTitle]);

  // SEO setup
  useSEO({
    title: service ? `${service.title} | AnkaPanjur` : "Hizmet Detayı | AnkaPanjur",
    description: service?.description ? service.description.substring(0, 160) : "AnkaPanjur profesyonel otomasyon sistemleri ve hizmet detayları.",
    keywords: `${service?.title || "hizmet"}, otomasyon, kepenk, kapı, güvenlik, ankapanjur`
  });
  
  // Service detail data based on title
  const getServiceDetails = (title: string) => {
    const serviceData: Record<string, any> = {
      "Otomatik Kepenk Sistemleri": {
        title: "Otomatik Kepenk Sistemleri",
        description: "AnkaPanjur otomatik kepenk sistemleri, modern yaşamın vazgeçilmezi haline gelen güvenlik ve konfor çözümleridir. 10 yıllık deneyimimizle Kocaeli'de en kaliteli alüminyum ve galvaniz kepenk sistemlerini sunuyoruz. CE belgeli ürünlerimiz ile maksimum güvenlik ve uzun ömür garantisi sağlıyoruz.",
        features: [
          "AnkaPanjur özel RF 433MHz uzaktan kumanda sistemi",
          "Rüzgar sensörü ile otomatik koruma (25 km/h üzeri)",
          "Rolling code güvenlik teknolojisi",
          "Ultra sessiz tubular motor (40dB altı)",
          "Acil durum kurtarma sistemi ve manuel çalıştırma",
          "Engel algılama sistemi ile güvenlik",
          "Zamanlayıcı ve hafıza özelliği",
          "AnkaPanjur 2 yıl motor garantisi",
          "IP65 dış mekan koruma sınıfı"
        ],
        applications: [
          "Villa ve konut dış kepenkleri - güvenlik ve ısı yalıtımı",
          "Bahçe ve teras girişleri - estetik ve fonksiyonel çözüm", 
          "Garaj kapıları - otomatik açılır kapanır sistem",
          "Dükkan vitrinleri - gece güvenliği ve gündüz görünürlük",
          "Ofis binaları - enerji tasarrufu ve güneş kontrolü",
          "Balkon kepenkleri - mahremiyet ve hava koşullarından korunma"
        ],
        technicalSpecs: {
          "Motor Gücü": "10Nm - 50Nm tubular motor",
          "Çalışma Voltajı": "220V AC / 24V DC seçenekleri",
          "Çalışma Hızı": "12-15 cm/sn ayarlanabilir",
          "Gürültü Seviyesi": "<40 dB ultra sessiz",
          "Çalışma Sıcaklığı": "-25°C / +70°C geniş aralık",
          "Malzeme": "6063-T5 alüminyum profil",
          "Lamel Kalınlığı": "8mm, 10mm, 12mm seçenekleri",
          "Renk Seçenekleri": "RAL standart renkler",
          "Koruma Sınıfı": "IP65 dış mekan uyumlu"
        },
        images: [
          "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=800&h=600&fit=crop"
        ]
      },
      
      "Endüstriyel Kapı Sistemleri": {
        title: "Endüstriyel Kapı Sistemleri",
        description: "AnkaPanjur endüstriyel kapı sistemleri, yoğun kullanıma dayanıklı, hızlı ve güvenli çözümler sunarak işletmenizin operasyonel verimliliğini maksimuma çıkarır. Seksiyonel, hızlı PVC ve çelik konstrüksiyon kapılarımız ile endüstriye özel ihtiyaçları karşılıyoruz.",
        features: [
          "AnkaPanjur yüksek performans motor sistemleri",
          "0.8-1.2 m/sn yüksek hızlı açılma-kapanma",
          "2 ton'a kadar ağır yük taşıma kapasitesi",
          "Siemens frekans invertörü ile hassas hız kontrolü",
          "Çift güvenlik ışın bariyeri sistemi",
          "Emergency stop ve acil açma sistemi",
          "Rüzgar yükü sensörü (100 km/h'ye dayanım)",
          "PLC kontrol sistemi entegrasyonu",
          "AnkaPanjur 15 yıl yapısal garanti",
          "CE belgeli Avrupa standartları"
        ],
        applications: [
          "Fabrika ana girişleri - yüksek trafik kapasitesi",
          "Depo yükleme rampaları - lojistik verimliliği",
          "Hangar ve atölye girişleri - geniş açıklık çözümleri",
          "Lojistik merkezleri - hızlı geçiş sistemleri",
          "Otopark ve garaj sistemleri - araç trafiği yönetimi",
          "Soğuk hava depoları - termal yalıtım özellikli"
        ],  
        technicalSpecs: {
          "Maksimum Boyut": "8m x 8m'ye kadar",
          "Kapasite": "500kg - 2000kg panel ağırlığı",
          "Açma Hızı": "25-40 cm/sn ayarlanabilir", 
          "Motor Gücü": "1.5kW - 7.5kW üç fazlı",
          "Çalışma Döngüsü": "1000+ açma/gün sürekli kullanım",
          "Rüzgar Dayanımı": "100 km/h rüzgar yükü",
          "Termal İletkenlik": "U=1.2 W/m²K yalıtım",
          "Koruma Sınıfı": "IP65 endüstriyel standart",
          "Kontrol Sistemi": "PLC veya klasik kontrol seçenekleri"
        },
        images: [
          "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800&h=600&fit=crop"
        ]
      },

      "Güvenlik Sistemleri": {
        title: "Güvenlik Sistemleri", 
        description: "AnkaPanjur entegre güvenlik sistemleri ile mülkünüzü 7/24 akıllı koruma altına alın. IP kamera sistemleri, alarm ve erişim kontrol çözümlerimiz ile tam güvenlik sağlıyoruz. Hikvision ve Dahua marka ürünlerle profesyonel güvenlik altyapısı kuruyoruz.",
        features: [
          "AnkaPanjur akıllı hareket algılama teknolojisi",
          "4K Ultra HD gece görüş kameraları (50m menzil)",
          "AnkaPanjur mobil uygulama - uzaktan izleme",
          "Bulut depolama + yerel NVR seçenekleri",
          "Sesli uyarı ve siren sistemleri",
          "Yüz tanıma ve plaka okuma teknolojisi",
          "PIR + mikrodalga hibrit sensörler",
          "GSM/WiFi çift haberleşme sistemi",
          "AnkaPanjur 2 yıl motor garantisi",
          "24/7 uzaktan sistem takibi"
        ],
        applications: [
          "Ev güvenlik sistemleri - aile ve mal güvenliği",
          "İş yeri ve fabrika korunması - endüstriyel güvenlik",
          "Apartman ve site girişleri - erişim kontrolü",
          "Villa ve müstakil ev güvenliği - çevre korunması",
          "Mağaza ve ofis korunması - hırsızlık önleme",
          "Okul ve hastane güvenliği - özel güvenlik ihtiyaçları"
        ],
        technicalSpecs: {
          "Kamera Çözünürlüğü": "4K (8MP) Ultra HD",
          "Depolama Kapasitesi": "1TB - 32TB NVR seçenekleri",
          "Görüş Açısı": "90° - 180° değişken lens",
          "Gece Görüş Mesafesi": "50m IR LED aydınlatma",
          "Zoom Özelliği": "4x optik, 16x dijital zoom",
          "Bağlantı Seçenekleri": "PoE, WiFi, 4G LTE",
          "Çalışma Sıcaklığı": "-40°C / +65°C",
          "Su Geçirmezlik": "IP67 dış mekan uyumlu",
          "Depolama Süresi": "30-90 gün otomatik kayıt"
        },
        images: [
          "https://images.unsplash.com/photo-1558002203-ea2c52c4da3a?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1596727147705-61a532a659bd?w=800&h=600&fit=crop"
        ]
      },

      "Fotoselli Kapı Sistemleri": {
        title: "Fotoselli Kapı Sistemleri",
        description: "AnkaPanjur fotoselli kapı sistemleri, günümüzün modern binalarında kullanım kolaylığı, hijyen ve enerji verimliliği sağlayan çözümlerdir. Temassız geçiş imkanı sunarak hem konfor hem de güvenlik sağlar. Kocaeli'nin tüm ilçelerinde yüksek kaliteli fotoselli kapı sistemleri kurulum ve bakım hizmetleri vermekteyiz.",
        features: [
          "Hareket sensörleri ve radar teknolojisi",
          "Temassız ve hijyenik geçiş imkanı",
          "Enerji verimli otomatik kapanma sistemi",
          "Ayarlanabilir sensör hassasiyeti",
          "Programlanabilir açılma/kapanma süresi",
          "Acil durum modu - elektrik kesintilerinde manuel kullanım",
          "Sessiz ve güçlü elektrik motorları",
          "Merkezi kontrol sistemi entegrasyonu",
          "AnkaPanjur kalite garantisi"
        ],
        applications: [
          "Hastaneler ve sağlık kuruluşları - temassız hijyenik geçiş",
          "Alışveriş merkezleri - yoğun insan trafiğinde konforlu geçiş",
          "Ofis binaları - modern görünüm ve kullanım kolaylığı",
          "Havalimanları ve istasyonlar - yüksek güvenlik ve hızlı geçiş",
          "Kamu binaları - güvenlik ve estetik amaçlı",
          "Otel ve konferans merkezleri - şıklık ve fonksiyonellik"
        ],
        technicalSpecs: {
          "Motor Gücü": "24V DC sessiz motor",
          "Sensör Tipleri": "Radar, kızılötesi, ultrasonik",
          "Açılma Hızı": "0.6-1.5 m/sn ayarlanabilir",
          "Malzeme": "Temperli cam, alüminyum, paslanmaz çelik",
          "Güvenlik": "IP54 koruma sınıfı",
          "Çalışma Voltajı": "220V AC / 24V DC",
          "Çalışma Sıcaklığı": "-20°C / +60°C",
          "Kapı Çeşitleri": "Yana kayar, sürgülü, döner, katlanır",
          "Kanat Seçenekleri": "İki kanatlı, dört kanatlı sistemler"
        },
        images: [
          "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&h=600&fit=crop"
        ]
      },

      "Panjur Sistemleri": {
        title: "Panjur Sistemleri",
        description: "AnkaPanjur panjur sistemleri, güneş kontrolü, güvenlik ve estetik açıdan mükemmel çözümler sunar. Alüminyum ve PVC malzeme seçenekleri ile dayanıklılık ve uzun ömür garantisi sağlıyoruz. CE belgeli profillerimiz ile Avrupa standartlarında kalite sunuyoruz.",
        features: [
          "6063-T5 alüminyum profil CE belgeli",
          "Elektrostatik toz boyama sistemi",
          "80mm ve 90mm lamel genişlik seçenekleri",
          "Otomatik ve manuel işletim seçenekleri",
          "Rüzgar sensörü ile otomatik koruma",
          "UV dayanımlı malzeme kullanımı",
          "Ses yalıtımı ve termal konfor",
          "AnkaPanjur 2 yıl motor garantisi",
          "Kolay bakım ve uzun ömür"
        ],
        applications: [
          "Konut balkon ve terrasları - güneş kontrolü",
          "Ofis binaları - enerji tasarrufu ve konfor",
          "Cafe ve restoranlar - mekan kontrolü",
          "Otel ve tatil köyleri - estetik ve fonksiyon",
          "Hastane ve okul binaları - güneş kontrolü",
          "Villa ve müstakil evler - mahremiyet sağlama"
        ],
        technicalSpecs: {
          "Profil Malzemesi": "6063-T5 alüminyum alaşımı",
          "Lamel Genişliği": "80mm, 90mm seçenekleri",
          "Renk Seçenekleri": "RAL standart tüm renkler",
          "Kaplama": "Elektrostatik toz boyama 60 mikron",
          "Rüzgar Dayanımı": "120 km/h rüzgar yükü",
          "Çalışma Açısı": "0° - 90° ayarlanabilir",
          "Montaj Sistemi": "Duvara, tavana, nişe montaj",
          "Kontrol Seçenekleri": "Manuel, motorlu, sensörlü",
          "Garantı Süresi": "10 yıl sistem garantisi"
        },
        images: [
          "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop"
        ]
      },

      "Kepenk Sistemleri": {
        title: "Kepenk Sistemleri",
        description: "AnkaPanjur kepenk sistemleri, güvenlik ve estetik ihtiyaçlarınızı bir arada karşılayan çözümlerdir. Alüminyum profil ve galvaniz çelik seçenekleri ile dayanıklılık garantisi sunuyoruz. Motorlu ve manuel seçeneklerle her ihtiyaca uygun çözümler.",
        features: [
          "Alüminyum ve galvaniz çelik profil seçenekleri",
          "Tubular motor sistemi (sessiz çalışma)",
          "RF 433MHz uzaktan kumanda",
          "Manuel ve otomatik işletim seçenekleri",
          "Güvenlik kilidi sistemi",
          "Hava koşullarına dayanıklı boyama",
          "Engel algılama güvenlik sistemi",
          "AnkaPanjur 2 yıl motor garantisi",
          "Kolay montaj ve bakım"
        ],
        applications: [
          "Dükkan vitrinleri - gece güvenliği",
          "Garaj kapıları - otomatik erişim",
          "Bahçe girişleri - güvenlik ve estetik",
          "Depo ve antrepo girişleri - koruma",
          "Konut giriş kapıları - güvenlik",
          "Ofis binası girişleri - kontrollü erişim"
        ],
        technicalSpecs: {
          "Profil Malzemesi": "Alüminyum / Galvaniz çelik",
          "Profil Kalınlığı": "1.2mm - 2.0mm",
          "Maksimum Boyut": "4m x 4m'ye kadar",
          "Motor Gücü": "120Nm - 300Nm seçenekleri",
          "Çalışma Hızı": "15-20 cm/sn",
          "Güvenlik": "Engel algılama sistemi",
          "Kontrol": "RF kumanda, anahtar, sensör",
          "Rüzgar Dayanımı": "100 km/h'ye kadar",
          "Garantı": "10 yıl motor, 15 yıl profil"
        },
        images: [
          "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?w=800&h=600&fit=crop"
        ]
      },

      "Otomatik Kayar Bahçe Kapısı": {
        title: "Otomatik Kayar Bahçe Kapısı",
        description: "AnkaPanjur otomatik kayar bahçe kapıları, modern yaşamın konfor ve güvenlik ihtiyaçlarını karşılayan akıllı çözümlerdir. Yüksek kaliteli malzeme ve güvenilir otomasyon sistemi ile uzun yıllar sorunsuz kullanım garantisi sunuyoruz.",
        features: [
          "Galvaniz çelik konstrüksiyon",
          "Otomatik kayar sistem (ray sistemi)",
          "RF uzaktan kumanda sistemi",
          "Fotosel güvenlik sistemi",
          "Manual açma sistemi (acil durum)",
          "LED warning ışığı sistemi",
          "Döner flaşör ikaz sistemi",
          "AnkaPanjur 2 yıl motor garantisi",
          "Hava koşullarına dayanıklı boyama"
        ],
        applications: [
          "Villa ve müstakil ev girişleri",
          "Site ve apartman girişleri", 
          "Fabrika ve tesis girişleri",
          "Otopark ve garaj girişleri",
          "Bahçe ve alan girişleri",
          "Güvenlik kontrol noktaları"
        ],
        technicalSpecs: {
          "Konstrüksiyon": "Galvaniz çelik profil",
          "Maksimum Genişlik": "6m'ye kadar",
          "Maksimum Ağırlık": "800kg'a kadar",
          "Motor Gücü": "550W - 750W",
          "Çalışma Hızı": "8-12 m/dk",
          "Güvenlik": "Fotosel, emniyet kenarlığı",
          "Kontrol": "RF kumanda, dijital keypad",
          "Ray Sistemi": "V-kayar ray sistemi",
          "Garantı": "10 yıl motor, 15 yıl yapısal"
        },
        images: [
          "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800&h=600&fit=crop"
        ]
      },

      "Seksiyonel Kapı Sistemleri": {
        title: "Seksiyonel Kapı Sistemleri",
        description: "AnkaPanjur seksiyonel kapı sistemleri, garaj ve endüstriyel alanlarda mükemmel yalıtım ve işlevsellik sağlar. Çelik konstrüksiyon ve yüksek kaliteli yalıtım malzemesi ile enerji tasarrufu ve konfor bir arada.",
        features: [
          "Çelik panel konstrüksiyon",
          "Poliüretan köpük yalıtım (40mm)",
          "Kırılmaz cam panel seçenekleri",
          "Otomatik açılma sistemi",
          "Güvenlik sensörleri sistemi",
          "Acil açma sistemi (manuel)",
          "Sessiz çalışma teknolojisi",
          "AnkaPanjur 2 yıl motor garantisi",
          "Bakım gerektirmeyen sistem"
        ],
        applications: [
          "Konut garajları - günlük kullanım",
          "Endüstriyel tesisler - ağır hizmet",
          "Otopark girişleri - yoğun trafik",
          "Depo ve antrepolar - lojistik",
          "Atölye ve hangar girişleri",
          "Soğuk hava depo girişleri"
        ],
        technicalSpecs: {
          "Panel Malzemesi": "Galvaniz çelik sac",
          "Yalıtım": "40mm poliüretan köpük",
          "Maksimum Boyut": "5m x 5m'ye kadar",
          "Termal İletkenlik": "U=0.7 W/m²K",
          "Motor Gücü": "500W - 1200W",
          "Çalışma Hızı": "20 cm/sn",
          "Güvenlik": "Anti-crushing sistemi",
          "Cam Seçenekleri": "Şeffaf, buzlu, bronz",
          "Garantı": "15 yıl yapısal, 10 yıl motor"
        },
        images: [
          "https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800&h=600&fit=crop"
        ]
      },

      "Giyotin Sistemleri": {
        title: "Giyotin Sistemleri", 
        description: "AnkaPanjur giyotin sistemleri, hızlı açılıp kapanan güvenlik çözümleri sunar. Yüksek güvenlik gerektiren alanlarda etkili koruma sağlayan bu sistemler, dayanıklı malzeme ve güvenilir mekanizma ile uzun ömürlü kullanım garantisi verir.",
        features: [
          "Ağır hizmet çelik konstrüksiyon",
          "Hızlı açılma-kapanma sistemi (3-5 saniye)",
          "Hidrolik veya elektrik motor seçenekleri",
          "Güvenlik sensörleri (fotosel)",
          "Manuel acil açma sistemi",
          "Anti-kırıcı güvenlik sistemi",
          "Rüzgar yükü dayanımı",
          "AnkaPanjur 2 yıl motor garantisi",
          "Minimum bakım gerektiren tasarım"
        ],
        applications: [
          "Fabrika ve tesis güvenlik girişleri",
          "Otopark çıkış kontrol noktaları",
          "Güvenlik karakol girişleri",
          "Askeri tesis giriş kontrolleri",
          "Hapishane ve cezaevi girişleri",
          "Yüksek güvenlik tesisleri"
        ],
        technicalSpecs: {
          "Konstrüksiyon": "S355 çelik profil",
          "Maksimum Boyut": "4m x 4m'ye kadar",
          "Panel Kalınlığı": "3mm - 5mm çelik sac",
          "Açılma Hızı": "0.8 - 1.2 m/sn",
          "Motor Gücü": "2.2kW - 5.5kW",
          "Güvenlik": "Fotosel, emniyet kenarı",
          "Rüzgar Dayanımı": "150 km/h'ye kadar",
          "Kontrol": "PLC kontrol sistemi",
          "Garantı": "10 yıl sistem, 15 yıl yapısal"
        },
        images: [
          "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=800&h=600&fit=crop"
        ]
      },

      "Pergole Sistemleri": {
        title: "Pergole Sistemleri",
        description: "AnkaPanjur pergole sistemleri, açık hava yaşam alanlarınızı hava koşullarından koruyarak konforlu kullanım imkanı sunar. Otomatik açılır kapanır tente sistemi ile güneş ve yağmur kontrolü sağlayarak dış mekan keyfinizi artırır.",
        features: [
          "Alüminyum profil konstrüksiyon",
          "Su geçirmez tente kumaşı (PVC)",
          "Otomatik açma-kapama sistemi",
          "Rüzgar sensörü otomatik koruma",
          "LED aydınlatma sistemi entegrasyonu",
          "Yan perdeleme seçenekleri",
          "RF uzaktan kumanda sistemi",
          "AnkaPanjur 2 yıl motor garantisi",
          "Bakım gerektirmeyen tasarım"
        ],
        applications: [
          "Cafe ve restoran terasları",
          "Konut balkon ve terasları",
          "Otel bahçe alanları",
          "Villa havuz kenarları",
          "Ofis bina terasları",
          "Alışveriş merkezi açık alanları"
        ],
        technicalSpecs: {
          "Konstrüksiyon": "6063-T5 alüminyum profil",
          "Maksimum Boyut": "6m x 4m'ye kadar",
          "Kumaş Tipi": "PVC, akrilik, polyester",
          "Motor Gücü": "24V DC tubular motor",
          "Rüzgar Dayanımı": "80 km/h (açık), 120 km/h (kapalı)",
          "Su Geçirmezlik": "IP65 standart",
          "Kontrol": "RF kumanda, duvar anahtarı",
          "Yan Perde": "Zip sistem yan perdeler",
          "Garantı": "10 yıl sistem, 5 yıl kumaş"
        },
        images: [
          "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop"
        ]
      },

      "Yangın Kapıları": {
        title: "Yangın Kapıları",
        description: "AnkaPanjur yangın kapıları, TSE belgeli Avrupa standartlarında üretilmiş can güvenliği sağlayan çözümlerdir. Yangın anında otomatik kapanma sistemi ve yüksek sıcaklık dayanımı ile güvenli tahliye imkanı sağlar.",
        features: [
          "TSE belgeli yangın dayanımı (60-120 dk)",
          "Otomatik kapanma sistemi",
          "Yüksek sıcaklık dayanımlı boyama",
          "Döner menteşe sistemi",
          "Panik bar acil çıkış sistemi",
          "Cam panel seçenekleri (yangın camı)",
          "Ses yalıtımı özelliği",
          "AnkaPanjur 2 yıl motor garantisi",
          "Avrupa CE standartları"
        ],
        applications: [
          "Hastane koridor ve bölüm girişleri",
          "Okul ve eğitim kurumu girişleri",
          "Otel kat ve bölüm girişleri",
          "Ofis binası acil çıkış yolları",
          "Fabrika bölüm ayırıcı kapıları",
          "AVM acil çıkış kapıları"
        ],
        technicalSpecs: {
          "Yangın Dayanımı": "EI 60, EI 90, EI 120 dakika",
          "Malzeme": "Galvaniz çelik konstrüksiyon",
          "Kalınlık": "54mm - 80mm",
          "Cam Seçenekleri": "Yangın dayanımlı cam",
          "Menteşe": "3 adet yangın menteşesi",
          "Panik Bar": "EN 1125 standart",
          "Boyama": "Elektrostatik toz boyama",
          "Belgeler": "TSE, CE belgeli",
          "Garantı": "15 yıl yapısal garanti"
        },
        images: [
          "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800&h=600&fit=crop"
        ]
      },

      "Kollu Bariyer Sistemleri": {
        title: "Kollu Bariyer Sistemleri",
        description: "AnkaPanjur kollu bariyer sistemleri, araç giriş-çıkış kontrolü sağlayan güvenilir otomasyon çözümleridir. Yüksek kaliteli malzeme ve hassas kontrol sistemi ile uzun ömürlü, güvenli kullanım garantisi sunuyoruz.",
        features: [
          "Alüminyum bariyer kolu (3-6m seçenekleri)",
          "Elektro-mekanik motor sistemi",
          "Fotosel güvenlik sistemi",
          "Loop dedektör entegrasyonu",
          "RF uzaktan kumanda sistemi",
          "LED ikaz ışığı sistemi",
          "Anti-vandal güvenlik kutusu",
          "AnkaPanjur 2 yıl motor garantisi",
          "Bakım gerektirmeyen tasarım"
        ],
        applications: [
          "Apartman ve site otopark girişleri",
          "AVM ve plaza otopark kontrolü",
          "Fabrika ve tesis araç girişleri",
          "Hastane otopark kontrol sistemi",
          "Okul araç giriş kontrolleri",
          "Kamu binası güvenlik kontrolü"
        ],
        technicalSpecs: {
          "Bariyer Uzunluğu": "3m, 4m, 5m, 6m seçenekleri",
          "Motor Gücü": "230V AC elektro-mekanik",
          "Açılma Hızı": "1.5 - 6 saniye ayarlanabilir",
          "Çalışma Döngüsü": "100% sürekli kullanım",
          "Güvenlik": "Fotosel, loop dedektör",
          "Kontrol": "RF kumanda, keypad, kart okuyucu",
          "Çalışma Sıcaklığı": "-25°C / +60°C",
          "Koruma Sınıfı": "IP54 dış mekan uyumlu",
          "Garantı": "10 yıl sistem garantisi"
        },
        images: [
          "https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?w=800&h=600&fit=crop",
          "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800&h=600&fit=crop"
        ]
      }
    };

    return serviceData[title] || {
      title: title,
      description: "Bu hizmet hakkında detaylı bilgi için bizimle iletişime geçin.",
      features: ["Profesyonel danışmanlık", "Kaliteli malzeme", "Uzman montaj"],
      applications: ["Konut", "Ticari", "Endüstriyel"],
      technicalSpecs: {},
      images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=600&fit=crop"]
    };
  };

  // Static service data removed - using database service data

  if (loading) {
    return (
      <div className="pt-20 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!service) {
    return (
      <div className="pt-20 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Hizmet Bulunamadı</h1>
          <Button onClick={() => setLocation('/')}>Ana Sayfaya Dön</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setLocation('/')}
              className="text-primary hover:text-primary/80"
            >
              <ArrowLeft size={20} className="mr-2" />
              Ana Sayfaya Dön
            </Button>
            <div className="h-6 w-px bg-gray-300"></div>
            <h1 className="text-2xl font-display font-bold text-gray-900">{service.title}</h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Hero Images */}
            {service.images && service.images.length > 0 && (
              <div className="space-y-4">
                <div className="aspect-video rounded-xl overflow-hidden shadow-lg">
                  <OptimizedImage 
                    src={service.images[0]} 
                    alt={service.title}
                    className="w-full h-full object-cover"
                    width={800}
                    height={450}
                    priority={true}
                  />
                </div>
                
                {service.images.length > 1 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {service.images.slice(1).map((image: string, index: number) => (
                      <div key={index} className="aspect-video rounded-lg overflow-hidden shadow-md">
                        <OptimizedImage 
                          src={image} 
                          alt={`${service.title} ${index + 2}`}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          width={300}
                          height={200}
                          lazy={true}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Description */}
            <div className="bg-white rounded-xl p-8 shadow-sm">
              <h2 className="text-2xl font-display font-bold text-gray-900 mb-4">Ürün Açıklaması</h2>
              <p className="text-gray-600 leading-relaxed text-lg">{service.description}</p>
            </div>

            {/* Features */}
            {service.features && service.features.length > 0 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl font-display font-bold text-gray-900 mb-6">Özellikler</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {service.features.map((feature: string, index: number) => (
                    <div key={index} className="flex items-start space-x-3">
                      <CheckCircle className="text-accent mt-1 flex-shrink-0" size={20} />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Applications */}
            {service.applications && service.applications.length > 0 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl font-display font-bold text-gray-900 mb-6">Kullanım Alanları</h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {service.applications.map((app: string, index: number) => (
                    <div key={index} className="bg-gray-50 rounded-lg p-4 text-center">
                      <div className="text-primary mx-auto mb-2 flex justify-center">
                        <Users size={24} />
                      </div>
                      <span className="text-gray-700 font-medium">{app}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Technical Specs */}
            {service.technicalSpecs && Object.keys(service.technicalSpecs).length > 0 && (
              <div className="bg-white rounded-xl p-8 shadow-sm">
                <h2 className="text-2xl font-display font-bold text-gray-900 mb-6">Teknik Özellikler</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  {Object.entries(service.technicalSpecs).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center py-3 border-b border-gray-100 last:border-0">
                      <span className="font-medium text-gray-900">{key}:</span>
                      <span className="text-gray-600">{String(value)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Card */}
            <div className="bg-white rounded-xl p-6 shadow-sm border-2 border-primary/10">
              <div className="text-center mb-6">
                <Star className="text-yellow-500 mx-auto mb-2" size={32} />
                <h3 className="text-xl font-display font-bold text-gray-900">İletişim</h3>
                <p className="text-gray-600 mt-2">Profesyonel ekibimiz size özel çözüm hazırlasın</p>
              </div>
              
              <div className="space-y-4">
                <Button 
                  className="w-full bg-accent hover:bg-accent/90 text-white"
                  onClick={() => {
                    const message = `Merhaba, ${service.title} hakkında bilgi almak istiyorum.`;
                    const phoneNumber = (companyInfo?.phone || COMPANY_INFO.phone).replace(/\s/g, "");
                    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
                    window.open(whatsappUrl, "_blank");
                  }}
                >
                  <MessageCircle className="mr-2" size={18} />
                  WhatsApp İletişim
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.open(`tel:${companyInfo?.phone || COMPANY_INFO.phone}`, "_self")}
                >
                  <Phone className="mr-2" size={18} />
                  Hemen Ara
                </Button>
              </div>
            </div>

            {/* Company Info */}
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h3 className="text-lg font-display font-bold text-gray-900 mb-4">İletişim Bilgileri</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Phone className="text-primary mt-1 flex-shrink-0" size={18} />
                  <div>
                    <p className="font-medium text-gray-900">Telefon</p>
                    <p className="text-gray-600">{companyInfo?.phone || COMPANY_INFO.phone}</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Mail className="text-primary mt-1 flex-shrink-0" size={18} />
                  <div>
                    <p className="font-medium text-gray-900">E-posta</p>
                    <p className="text-gray-600">{companyInfo?.email || COMPANY_INFO.email}</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MapPin className="text-primary mt-1 flex-shrink-0" size={18} />
                  <div>
                    <p className="font-medium text-gray-900">Adres</p>
                    <p className="text-gray-600">{COMPANY_INFO.address}</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Clock className="text-primary mt-1 flex-shrink-0" size={18} />
                  <div>
                    <p className="font-medium text-gray-900">Çalışma Saatleri</p>
                    <p className="text-gray-600">Pzt-Cum: 08:00-18:00</p>
                    <p className="text-gray-600">Cmt: 09:00-17:00</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Why Choose Us */}
            <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl p-6">
              <h3 className="text-lg font-display font-bold text-gray-900 mb-4">Neden AnkaPanjur?</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="text-accent" size={16} />
                  <span className="text-sm text-gray-700">25+ yıl deneyim</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="text-accent" size={16} />
                  <span className="text-sm text-gray-700">10.000+ başarılı proje</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="text-accent" size={16} />
                  <span className="text-sm text-gray-700">ISO 9001 sertifikalı</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="text-accent" size={16} />
                  <span className="text-sm text-gray-700">7/24 teknik destek</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}