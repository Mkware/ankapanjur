import { ExpandIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import OptimizedImage from "./OptimizedImage";

interface ProjectCardProps {
  title: string;
  description: string;
  image: string;
  category: string;
  onImageClick: (image: string) => void;
}

export default function ProjectCard({ title, description, image, category, onImageClick }: ProjectCardProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "industrial":
        return "text-primary";
      case "commercial":
        return "text-green-600";
      case "residential":
        return "text-purple-600";
      default:
        return "text-gray-600";
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "industrial":
        return "Endüstriyel";
      case "commercial":
        return "Ticari";
      case "residential":
        return "Konut";
      default:
        return category;
    }
  };

  return (
    <Card className="card-hover bg-white rounded-xl shadow-lg overflow-hidden">
      <OptimizedImage 
        src={image} 
        alt={title} 
        className="w-full h-64 object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
        width={400}
        height={256}
        lazy={true}
        onClick={() => onImageClick(image)}
      />
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <div className="flex items-center justify-between">
          <span className={`text-sm font-medium ${getCategoryColor(category)}`}>
            {getCategoryLabel(category)}
          </span>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onImageClick(image)}
            className="text-primary hover:text-primary/80"
          >
            <ExpandIcon size={16} />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
