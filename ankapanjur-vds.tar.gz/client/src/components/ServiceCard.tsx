import { ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import OptimizedImage from "./OptimizedImage";

interface ServiceCardProps {
  title: string;
  description: string;
  image: string;
  icon?: React.ComponentType<{ size?: number }>;
}

export default function ServiceCard({ title, description, image, icon: Icon }: ServiceCardProps) {
  return (
    <Card className="card-hover bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100">
      <OptimizedImage 
        src={image} 
        alt={title} 
        className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300" 
        width={400}
        height={192}
        lazy={true}
      />
      <CardContent className="p-6">
        <div className="flex items-center mb-3">
          <div className="text-primary mr-2">
            {Icon ? <Icon size={24} /> : <div className="w-6 h-6 bg-primary/20 rounded" />}
          </div>
          <h3 className="text-xl font-bold text-gray-800">{title}</h3>
        </div>
        <p className="text-gray-600 mb-4">{description}</p>
        <Button 
          variant="ghost" 
          className="text-primary hover:text-white hover:bg-primary p-0 hover:px-3 hover:py-2 transition-all duration-300 ease-in-out rounded-md"
          onClick={() => {
            window.location.href = `/hizmet-detay?service=${encodeURIComponent(title)}`;
          }}
        >
          Detayları Gör <ArrowRight className="ml-2" size={16} />
        </Button>
      </CardContent>
    </Card>
  );
}
