import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export default function Logo({ className = '', size = 'md' }: LogoProps) {
  const sizeClasses = {
    sm: 'w-28 h-8',
    md: 'w-36 h-10',
    lg: 'w-44 h-12',
    xl: 'w-52 h-16'
  };

  return (
    <svg 
      className={`${sizeClasses[size]} ${className}`}
      viewBox="0 0 180 50" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="primaryGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="hsl(217, 91%, 22%)" />
          <stop offset="100%" stopColor="hsl(142, 76%, 22%)" />
        </linearGradient>
      </defs>
      
      {/* Modern geometric icon */}
      <g transform="translate(5, 8)">
        {/* Main diamond shape */}
        <path d="M15 0 L30 8 L25 20 L5 20 L0 8 Z" fill="url(#primaryGrad)" />
        
        {/* Inner lines for depth */}
        <path d="M6 10 L24 10" stroke="white" strokeWidth="1.5" opacity="0.7" />
        <path d="M8 14 L22 14" stroke="white" strokeWidth="1.5" opacity="0.5" />
        
        {/* Corner accent */}
        <circle cx="25" cy="8" r="2" fill="hsl(142, 76%, 40%)" />
      </g>
      
      {/* Company name with bold typography */}
      <text x="42" y="22" fontSize="16" fontWeight="800" fill="hsl(217, 91%, 22%)" fontFamily="Inter, sans-serif">
        ANKA
      </text>
      <text x="85" y="22" fontSize="16" fontWeight="800" fill="hsl(142, 76%, 22%)" fontFamily="Inter, sans-serif">
        PANJUR
      </text>
      
      {/* Clean subtitle */}
      <text x="42" y="35" fontSize="7" fontWeight="500" fill="hsl(217, 91%, 45%)" fontFamily="Inter, sans-serif">
        OTOMATİK KEPENK SİSTEMLERİ
      </text>
    </svg>
  );
}