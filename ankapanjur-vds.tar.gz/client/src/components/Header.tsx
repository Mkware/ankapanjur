import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Phone, Menu, X, Facebook, Instagram, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { COMPANY_INFO } from "@/lib/constants";
import Logo from "@/components/Logo";
import { useQuery } from "@tanstack/react-query";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();

  // Fetch company info from database
  const { data: companyInfo } = useQuery({
    queryKey: ['/api/public/company-info'],
  });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { href: "/", label: "Ana Sayfa" },
    { href: "/hakkimizda", label: "Hakkımızda" },
    { href: "/urunler", label: "Ürünler" },
    { href: "/iletisim", label: "İletişim" },
  ];

  const scrollToSection = (sectionId: string) => {
    if (location === "/") {
      const element = document.getElementById(sectionId);
      if (element) {
        const offsetTop = element.offsetTop - 80;
        window.scrollTo({
          top: offsetTop,
          behavior: "smooth"
        });
      }
    }
  };

  return (
    <header className={`sticky-nav bg-white shadow-lg fixed w-full top-0 z-50 ${isScrolled ? 'shadow-xl' : ''}`}>
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <Logo size="lg" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-gray-700 hover:text-primary font-medium transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Contact Info */}
          <div className="hidden md:flex items-center space-x-4">
            <a
              href={`tel:${companyInfo?.phone || COMPANY_INFO.phone}`}
              className="flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors"
            >
              <Phone size={16} />
              <span className="font-medium">{companyInfo?.phone || COMPANY_INFO.phone}</span>
            </a>
            <div className="flex space-x-2">
              <a href={COMPANY_INFO.social.instagram} className="text-pink-600 hover:text-pink-700 text-lg">
                <Instagram size={16} />
              </a>
              <a href={COMPANY_INFO.social.linkedin} className="text-blue-700 hover:text-blue-800 text-lg">
                <Linkedin size={16} />
              </a>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-3">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-gray-700 hover:text-primary font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <div className="pt-3 border-t">
                <a
                  href={`tel:${companyInfo?.phone || COMPANY_INFO.phone}`}
                  className="flex items-center space-x-2 text-primary"
                >
                  <Phone size={16} />
                  <span>{companyInfo?.phone || COMPANY_INFO.phone}</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
