#!/bin/bash

# AnkaPanjur Ubuntu 22.04 VDS Deployment Script
# Otomatik kurulum scripti

set -e

# Renkler
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# VDS bilgileri
VDS_IP="89.47.113.251"
DOMAIN="ankapanjur.com"
APP_USER="ubuntu"
APP_DIR="/home/$APP_USER/ankapanjur"
PG_PASSWORD="AnkaPanjur2024!$(date +%s)"
SESSION_SECRET="ankapanjur_session_$(openssl rand -hex 32)"

echo -e "${BLUE}AnkaPanjur VDS Deployment${NC}"
echo "VDS: $VDS_IP | Domain: $DOMAIN"
echo "========================================"

# Root kontrolü
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Bu script sudo ile çalıştırılmalıdır!${NC}"
    echo "Kullanım: sudo bash deploy.sh"
    exit 1
fi

# 1. Sistem güncellemesi
echo -e "${YELLOW}[1/12] Sistem güncelleniyor...${NC}"
apt update -y && apt upgrade -y
apt install -y curl wget git unzip nano htop ufw

# 2. Node.js 18.x LTS kurulumu
echo -e "${YELLOW}[2/12] Node.js kuruluyor...${NC}"
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
fi
echo "Node.js version: $(node --version)"

# 3. PostgreSQL kurulumu
echo -e "${YELLOW}[3/12] PostgreSQL kuruluyor...${NC}"
if ! command -v psql &> /dev/null; then
    apt install -y postgresql postgresql-contrib
    systemctl start postgresql
    systemctl enable postgresql
fi

# 4. PostgreSQL yapılandırması
echo -e "${YELLOW}[4/12] PostgreSQL yapılandırılıyor...${NC}"
sudo -u postgres psql -c "DROP DATABASE IF EXISTS ankapanjur_db;" || true
sudo -u postgres psql -c "DROP USER IF EXISTS ankapanjur_user;" || true
sudo -u postgres psql -c "CREATE USER ankapanjur_user WITH PASSWORD '$PG_PASSWORD';"
sudo -u postgres psql -c "CREATE DATABASE ankapanjur_db OWNER ankapanjur_user;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ankapanjur_db TO ankapanjur_user;"

# 5. Kullanıcı kontrolü
echo -e "${YELLOW}[5/12] Uygulama kullanıcısı kontrol ediliyor...${NC}"
if ! id "$APP_USER" &>/dev/null; then
    useradd -m -s /bin/bash "$APP_USER"
    usermod -aG sudo "$APP_USER"
fi

# 6. Uygulama dizini
echo -e "${YELLOW}[6/12] Uygulama dizini hazırlanıyor...${NC}"
mkdir -p "$APP_DIR"
chown "$APP_USER:$APP_USER" "$APP_DIR"

# 7. .env dosyası
echo -e "${YELLOW}[7/12] Environment dosyası oluşturuluyor...${NC}"
cat > "$APP_DIR/.env" << EOF
DATABASE_URL=postgresql://ankapanjur_user:$PG_PASSWORD@localhost:5432/ankapanjur_db
PGHOST=localhost
PGPORT=5432
PGUSER=ankapanjur_user
PGPASSWORD=$PG_PASSWORD
PGDATABASE=ankapanjur_db
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
SESSION_SECRET=$SESSION_SECRET
UPLOAD_DIR=./uploads
SITE_URL=https://$DOMAIN
EOF

chmod 600 "$APP_DIR/.env"
chown "$APP_USER:$APP_USER" "$APP_DIR/.env"

# 8. Upload klasörleri
echo -e "${YELLOW}[8/12] Upload klasörleri oluşturuluyor...${NC}"
mkdir -p "$APP_DIR/uploads/services" "$APP_DIR/uploads/projects"
chown -R "$APP_USER:$APP_USER" "$APP_DIR/uploads"
chmod -R 755 "$APP_DIR/uploads"

# 9. NPM paketleri (proje dosyaları yüklendikten sonra)
echo -e "${YELLOW}[9/12] NPM paketleri yüklenecek...${NC}"
echo "Proje dosyalarını yükledikten sonra çalıştırın:"
echo "cd $APP_DIR && npm install"

# 10. PM2 kurulumu
echo -e "${YELLOW}[10/12] PM2 kuruluyor...${NC}"
npm install -g pm2

# PM2 ecosystem dosyası
cat > "$APP_DIR/ecosystem.config.js" << EOF
module.exports = {
  apps: [{
    name: 'ankapanjur',
    script: 'npm',
    args: 'start',
    cwd: '$APP_DIR',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0'
    }
  }]
};
EOF

# 11. Nginx kurulumu
echo -e "${YELLOW}[11/12] Nginx kuruluyor...${NC}"
apt install -y nginx

cat > "/etc/nginx/sites-available/ankapanjur" << EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN $VDS_IP;

    client_max_body_size 50M;

    location /uploads/ {
        alias $APP_DIR/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

ln -sf /etc/nginx/sites-available/ankapanjur /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx
systemctl enable nginx

# 12. Firewall
echo -e "${YELLOW}[12/12] Firewall ayarlanıyor...${NC}"
ufw --force enable
ufw allow ssh
ufw allow 80
ufw allow 443
ufw allow 5000

echo
echo -e "${GREEN}======================================${NC}"
echo -e "${GREEN}VDS HAZIRLIK TAMAMLANDI!${NC}"
echo -e "${GREEN}======================================${NC}"
echo
echo -e "${BLUE}Sonraki Adımlar:${NC}"
echo "1. Proje dosyalarını $APP_DIR klasörüne yükleyin"
echo "2. cd $APP_DIR && npm install"
echo "3. npm run db:push"
echo "4. npx tsx scripts/seed.ts"
echo "5. pm2 start ecosystem.config.js"
echo
echo -e "${BLUE}Veritabanı Bilgileri:${NC}"
echo "PostgreSQL Kullanıcı: ankapanjur_user"
echo "PostgreSQL Şifre: $PG_PASSWORD"
echo "Veritabanı: ankapanjur_db"
echo
echo -e "${BLUE}Erişim:${NC}"
echo "Web: http://$VDS_IP:5000"
echo "Admin: http://$VDS_IP:5000/admin"
echo "Kullanıcı: admin / admin123"
echo
echo -e "${YELLOW}Bu bilgileri kaydedin!${NC}"