# AnkaPanjur Ubuntu 22.04 VDS Deployment

## VDS Bilgileri
- **IP:** 89.47.113.251
- **Domain:** ankapanjur.com
- **OS:** Ubuntu 22.04 LTS

## Kurulum Adımları

### 1. VDS'e Bağlanın
```bash
ssh root@89.47.113.251
# veya
ssh ubuntu@89.47.113.251
```

### 2. Deployment Script Çalıştırın
```bash
# Script'i VDS'e yükleyin (deploy.sh)
chmod +x deploy.sh
sudo ./deploy.sh
```

### 3. Proje Dosyalarını Yükleyin
```bash
# FileZilla/WinSCP ile tüm proje dosyalarını /home/ubuntu/ankapanjur/ klasörüne yükleyin
# Veya git clone kullanın
```

### 4. Uygulama Kurulumu
```bash
cd /home/ubuntu/ankapanjur
npm install
npm run db:push
npx tsx scripts/seed.ts
```

### 5. Uygulamayı Başlatın
```bash
pm2 start ecosystem.config.js
pm2 startup
pm2 save
```

## Erişim Bilgileri

### Web Sitesi
- **URL:** http://89.47.113.251:5000
- **Domain:** http://ankapanjur.com (DNS ayarlandıktan sonra)

### Admin Paneli
- **URL:** http://89.47.113.251:5000/admin
- **Kullanıcı:** admin
- **Şifre:** admin123

## DNS Ayarları

Domain sağlayıcınızdan:
```
A Record: ankapanjur.com → 89.47.113.251
A Record: www.ankapanjur.com → 89.47.113.251
```

## SSL Sertifikası

DNS ayarları aktif olduktan sonra:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d ankapanjur.com -d www.ankapanjur.com
```

## Faydalı Komutlar

### Uygulama Yönetimi
```bash
pm2 status                    # Durum kontrolü
pm2 logs ankapanjur          # Log görüntüleme
pm2 restart ankapanjur       # Yeniden başlatma
pm2 stop ankapanjur          # Durdurma
```

### Sistem Kontrolleri
```bash
sudo systemctl status nginx     # Nginx durumu
sudo systemctl status postgresql # PostgreSQL durumu
curl http://localhost:5000      # Local test
```

### Veritabanı Erişimi
```bash
psql -U ankapanjur_user -h localhost ankapanjur_db
```

## Sorun Giderme

### Port 5000'e erişilemiyor
```bash
sudo ufw allow 5000
pm2 restart ankapanjur
sudo systemctl restart nginx
```

### PostgreSQL bağlantı sorunu
```bash
sudo systemctl restart postgresql
```

### Nginx 502 Hatası
```bash
pm2 status
pm2 restart ankapanjur
sudo nginx -t
sudo systemctl restart nginx
```

## Dosya Yapısı

Proje dosyaları `/home/ubuntu/ankapanjur/` klasöründe olmalı:
```
/home/ubuntu/ankapanjur/
├── client/
├── server/
├── shared/
├── scripts/
├── public/
├── uploads/
├── package.json
├── .env
└── ecosystem.config.js
```

## Güvenlik

- Firewall aktif (UFW)
- PostgreSQL yerel erişim
- Session secrets otomatik oluşturulan
- Upload klasörleri güvenli izinler
- Admin şifresi ilk girişte değiştirin